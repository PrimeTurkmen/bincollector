# Pilot API v3 — endpoint quick reference

Servers (production paths):
  - https://boooch.pilot-gps.com
  - https://pilot-gps.com
  - https://pilot-gps.africa
  - https://blade.pilot-gps.com
  - https://ksa.pilot-gps.com

Auth: `POST /api/v3/auth/token` → returns `token` + `node_id`. Use `Authorization: Bearer {token}` and `X-Node-Id: {node_id}` on every request.


## Auth

### `POST /api/v3/auth/token` — Get access token
opId: `getToken`
> Authenticates by login and password and returns a token, which must be sent in the `Authorization: Bearer {token}` header. The response also returns `node_id`, which must be sent in the `X-Node-Id` header in all subsequent API v3 requests.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
Body (application/json):
  - `username` (string) *req* — User login
  - `password` (string) *req* — User password

### `GET /api/v3/auth/me` — Get current authenticated user
> Returns information about the currently authenticated user. Requires an active session and/or a valid token used as session_id.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend


## Drivers

### `GET /api/v3/ibuttons` — Global iButton list
opId: `listIButtons`
> iButton usage history across all vehicles.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/ibuttons` — iButton history for a vehicle
opId: `getIButtonsForVehicle`
> iButton usage history for a specific vehicle.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/drivers` — Drivers list
opId: `listDrivers`
> Returns the list of drivers.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend

### `POST /api/v3/drivers` — Create or update driver
opId: `createOrUpdateDriver`
> Creates or updates a driver record.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
Body (application/json, schema DriverCreateRequest):
  - `name` (string) — 
  - `code` (string) — 
  - `description` (string) — 
  - `phone` (string) — 
  - `license` (string) — 
  - `email` (string) — 
  - `access` (array) — 

### `GET /api/v3/drivers/activity` — Driver activity
opId: `getDriverActivity`
> Returns driver activity data for the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `driver_id` (query, integer, *req*) — 
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `POST /api/v3/vehicles/driver-bind` — Bind driver to vehicle
opId: `bindDriverToVehicle`
> Binds a driver (by name or code) to a vehicle.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `driver_id` (query, integer, opt) — 
  - `ibutton` (query, string, opt) — 


## Fuel

### `GET /api/v3/fuel/stations` — Fuel stations list
opId: `listFuelStations`
> Returns the list of fuel stations.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend

### `POST /api/v3/fuel/transactions` — Add fuel card transaction
opId: `addFuelTransaction`
> Adds a fuel card transaction.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
Body (application/json, schema FuelTransactionCreateRequest):
  - `card_num` (string) *req* — 
  - `operation` (string) *req* — 
  - `unixtimestamp` (integer) *req* — 
  - `place` (string) *req* — 
  - `azs` (string) *req* — 
  - `liters` (number) *req* — 
  - `fuel` (string) *req* — 
  - `price` (number) *req* — 
  - `sum` (number) *req* — 
  - `priceg` (number) — 
  - `sumg` (number) — 
  - `driver` (string) — 
  - `lat` (number) — 
  - `lon` (number) — 
  - `info` (string) — 
  - `internal_id` (string) — 

### `GET /api/v3/vehicles/fuel` — Detailed fuel data
opId: `getFuelDetails`
> Detailed fuel report: refuels, drains, daily balances, and and related aggregates.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/fuel/consumption` — Fuel consumption and idle time
opId: `getFuelConsumption`
> Returns consumed fuel and idle time.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/odo-fuel` — Odometer and fuel for a period
opId: `getOdoAndFuel`
> Returns mileage and fuel for the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)


## Geo

### `GET /api/v3/geofences` — Geofence list
opId: `listGeofences`
> Returns the list of geofences.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend

### `POST /api/v3/geofences` — Create geofence
opId: `createGeofence`
> Creates a new geofence.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
Body (application/json, schema GeofenceAdd):
  - `type` (string ['polygon', 'circle', 'line']) *req* — Geofence type
  - `name` (string) *req* — Zone name
  - `color` (string) — Color
  - `info` (string) — Info
  - `group_name` (string) *req* — Group name
  - `points` (?) *req* — Geofence coordinates
  - `width` (number) — Line width

### `DELETE /api/v3/geofences` — Delete geofence
opId: `deleteGeofence`
> Deletes a geofence by ID.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `id` (query, integer, opt) — 
  - `external_id` (query, string, opt) — 

### `GET /api/v3/geofences/visits` — Geofence visit history
opId: `getGeofenceVisits`
> History of entries to and exits from geofences.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id

### `GET /api/v3/geofences/mileage` — Mileage in geofences
opId: `getZonesMileage`
> Returns mileage by geofences for the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `fences` (query, string, opt) — Comma-separated list of geofence names


## Notifications

### `GET /api/v3/notifications` — Notification module events
opId: `listNotifications`
> Returns Notification module events for the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)
  - `notification` (query, string, opt) — Notification name

### `GET /api/v3/events/live` — Live events
opId: `getLiveEvents`
> Stream of current events.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend

### `GET /api/v3/stations/{stopId}/forecast` — Get station arrival forecast
opId: `getStationForecast`
> Returns the arrival forecast for the specified station.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `stopId` (path, integer, *req*) — 


## Sensors

### `GET /api/v3/vehicles/sensors/dip` — History of dip sensor readings
opId: `getSensorsHistory`
> Returns the history of readings for all connected sensors over the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)
  - `tag_id` (query, string, opt) — Comma-separated sensor tags (tag_id)

### `GET /api/v3/vehicles/sensors/discrete` — Discrete sensor history
opId: `getDiscreteSensorData`
> History of discrete sensor states.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)
  - `tag_id` (query, string, opt) — Comma-separated sensor tags (tag_id)

### `GET /api/v3/vehicles/sensors/eco` — Eco-driving and equipment operation
opId: `getEcoDrive`
> Returns eco-driving metrics and equipment operation data.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)


## Tracks

### `GET /api/v3/vehicles/track` — Movement track for a period
opId: `getTrack`
> Returns the sequence of movement points.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)
  - `fences` (query, integer [0, 1], opt) — Whether to include geofence information
  - `eco` (query, integer [0, 1], opt) — Whether to include eco-driving metrics

### `GET /api/v3/vehicles/track/geo` — Trips and parking report
opId: `getTrackGeo`
> Returns the structure of trips and parking intervals for the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/track/stops` — Stops report
opId: `getTrackStops`
> Returns the list of stops / parking intervals for the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/forecast_here` — Route arrival forecast using the HERE service
opId: `getRoute`
> Route arrival forecast using the HERE service. A HERE service key must be configured in the contract settings to use this endpoint.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `mode` (query, string ['car', 'truck', 'bus', 'taxi', 'scooter', 'bicycle', 'pedestrian'], opt) — Transport type, one of bicycle - bicycle bus - bus car - car pedestrian - pedestrian scoot
  - `origin` (query, string, *req*) — Start point coordinates in `lat,lon` format
  - `destination` (query, string, *req*) — Destination point coordinates in `lat,lon` format

### `GET /api/v3/vehicles/trips` — Summary of trips, parking, speed, and parking intervals
opId: `getDistanceSummary`
> Returns total mileage, travel time, average and maximum speed
> and other aggregated information.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/events/raw` — Raw points by vehicle
opId: `getRawEvents`
> Returns raw data points for the vehicle over the selected period.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/passengers` — Passenger flow data
opId: `getPassengerCounter`
> Returns passenger counter data.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)
  - `te` (query, integer, *req*) — End time (UTC) of the period (Unix timestamp)


## Vehicles

### `GET /api/v3/vehicles` — Vehicles list
opId: `listVehicles`
> Returns the list of vehicles for the current account.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend

### `GET /api/v3/vehicles/by-plate` — Get IMEI by license plate
opId: `getImeiByPlate`
> Returns the IMEI by the vehicle license plate.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `vehnum` (query, string, *req*) — Vehicle license plate number (as stored in Pilot)

### `GET /api/v3/vehicles/status` — Current vehicle status
opId: `getVehicleStatus`
> Returns the current status of vehicles: coordinates, speed, direction, sensor states, and so on.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Comma-separated list of vehicle IMEIs
  - `agent_id` (query, string, opt) — Comma-separated list of Agent IDs

### `GET /api/v3/vehicles/last24h` — Vehicle status for the last 24 hours
opId: `VehicleStatus24`
> Vehicle data for the last 24 hours.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id

### `GET /api/v3/vehicles/instant-status` — Mileage and fuel at a point in time
opId: `getInstantStatus`
> Returns the odometer and fuel level at a specific point in time.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `ts` (query, integer, *req*) — Start time (UTC) of the period (Unix timestamp)

### `GET /api/v3/vehicles/share-link` — Create temporary tracking link
opId: `createTempLink`
> Creates a temporary link for tracking a vehicle.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `startgeo` (query, string, opt) — Geofence for link activation
  - `stopgeo` (query, string, opt) — Geofence for link deactivation
  - `max_duration` (query, integer, opt) — Duration in minutes during which the logic remains active regardless of geofence visits

### `POST /api/v3/vehicles/commands` — Send command to vehicle
opId: `sendVehicleCommand`
> Sends a command to the vehicle by template name.
> Maps to legacy cmd=send_command.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
Body (application/json, schema VehicleCommandRequest):
  - `template_name` (string) *req* — 
  - `params` (object) — 

### `GET /api/v3/vehicles/commands/status` — Get command status
opId: `getVehicleCommandStatus`
> Returns the status of a previously sent command.
> Maps to legacy cmd=get_command_status.
Params:
  - `X-Node` (header, integer, opt) — User node used to route the request to the correct backend
  - `imei` (query, string, opt) — Vehicle IMEI
  - `agent_id` (query, integer, opt) — Vehicle agent_id
  - `command_id` (query, integer, *req*) — 

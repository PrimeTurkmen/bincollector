# Pilot API legacy (v.2 + admin) — full command list with examples

All commands hit `/api/api.php` (user) or `/ax/api.php` (admin) using HTTP Basic auth.

Common pattern: `cmd=<command>&node=<node_num>` plus command-specific params.

Response: JSON `{ "code": 0, "msg": "OK", ... }` (use `out=xml` for XML).


## Administrator API (`/ax/api.php`)

### Creating an account — POST `accountadd`
This API is used to create a new account, including account information and user data (such as the administrator’s login and password). After the request is executed, an account with a unique ID is created, and the first user (administrator) is added with the specified login and password.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/ax/api.php?

### Method

POST

### Request parameters

Required parameters:

• cmd=accountadd — command to add a new contract

• bill_price — ID of the pricing list (must be retrieved via the pricelist command)

• inn — taxpayer identification number (TIN) of the organization

  * node — the number of the node where the command should be executed




Optional parameters:

• acc_deposit — deposit amount (default is 0)

• acc_type — billing type:

— 1 — postpaid (default)

— 2 — prepaid

— 3 — postpaid light (with disconnection threshold)

• org_type — organization type:

— 1 — legal entity (default)

— 2 — individual

— 3 — sole proprietor

• bill_phone — organization’s phone number

• comment — comment for the contract

• code — 1C code

• kpp — KPP (Tax Registration Reason Code)

• block_limit — disconnection threshold for postpaid light billing type

• modules — IDs of connected modules (comma-separated, retrieved from modlist)

• bill_email — email address for the contract

• org_name — organization name

### Example request

| https://<server_address>/ax/api.php?cmd=accountadd&bill_price=143&bill_email=demo1@skyelectronics.ru&org_name=PUP&comment=lalala&inn=123456789012&acc_type=1&org_type=1&node=1  
---|---  
  
Response

| { "code": 0, "data": { "id": "4018", "login": "demo1@skyelectronics.ru", "password": "blPs0S" }, "msg": "OK" }  
---|---  
  
The response to the API request will include:

• code — response status

— 0 — operation successful

• data — information about the new contract

• id — unique contract ID

• login — administrator login created for the contract

• password — administrator password

• msg — message indicating the result of the operation

### Accounts list — GET `accountslist`
This API retrieves the list of accounts with basic information: contract ID, name, balance, and the number of vehicles.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=accountslist— command to retrieve the list of accounts

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=accountslist&node=1  
---|---  
  
Response

| { "id": 1003, "org_name": "software_testing", "org_type": 1, "balance": "0.00", "acc_deposit": "0.00", "comment": null, "inn": "1", "kpp": "1", "bill_email": "102.ru", "bill_phone": "1", "veh_count": 13 }  
---|---  
  
In response to the API request, the following is returned:

  * id — unique account identifier

  * org_name — organization or contract name

  * org_type — type of organization 

  * balance — current contract balance

  * acc_deposit — deposit amount on the contract 

  * comment — additional comment for the contract 

  * inn — tax identification number (TIN) of the organization

  * kpp — tax registration reason code (if applicable)

  * bill_email — email address for billing or invoicing notifications

  * bill_phone — contact phone number for billing inquiries

  * veh_count — number of vehicles linked to the account

### Account users list — GET `users`
This API allows you to retrieve a list of users for a specific account with basic information for each user.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=users — command to get the list of users

  * accountid — ID of the account whose users are being requested

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=users&accountid=56832&node=1  
---|---  
  
Response

| { "data": [ { "id": 88977, "name": "valera_test", "login": "valera17totsenko@gmail.com", "passwd": "123456", "info": null, "email": "valera17totsenko@gmail.com", "lang": "en", "roleid": 0 } ], "code": 0, "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * id — user ID

  * name — display name

  * login — username/login

  * passwd — password

  * info — additional user information

  * email — email address

  * lang — user interface language

  * roleid — role ID

### Tariff plans list — GET `pricelist`
This API allows you to retrieve a list of tariffs available for an account, including information about the currency, price, and description.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=pricelist— command to get the list of tariffs

  * node — the number of the node where the command should be executed

  * coden (optional) — currency code:

— numeric (e.g., 840 for USD, 810 for RUB)

— alphabetic (e.g., USD or RUR)




### Example request

| https://<server_address>/backend/api.php?cmd=pricelist&coden=840&node=1  
---|---  
  
Response

| { "code": 0, "data": [ { "id": 143, "code": "840", "currency": 2, "descr": "3 dollars per property per month", "name": "US dollar", "price": "3.00" } ], "message": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — request result code (0 = successful)

  * data — array of tariff objects:

  * id — unique tariff ID

  * code — currency code (numeric)

  * currency — internal currency ID

  * descr — tariff description

  * name — tariff name (e.g., "US dollar")

  * price — tariff price in the specified currency

  * message — text message with the result of the request

### Adding payments — POST `payment`
This API is used to add payment information for an account. You can specify the amount, date, external payment ID, and description.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/ax/api.php?

Request parameters

  * cmd=payment — command to add a payment

  * inn — account’s INN (unique identifier)

  * sum — payment amount (format dd.dd)

  * id — payment ID in the external system

  * date — payment date (format DDMMYYYY)

  * descr — payment description (string), e.g., “payment for connection”

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/ax/api.php?cmd=payment&inn=123123123&sum=10.00&id=124&date=04042016&descr=test%20payment&node=1  
---|---  
  
Response

| { "code": 0, "msg": "Payment inserted successfully", "data": { "payment_id": 124, "inn": "123123123", "sum": 10.00, "date": "04042016", "descr": "test payment" } }  
---|---

### Adding a vehicle to an account — POST `vehadd`
To add a vehicle to your account, use this API.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

To obtain the required data, append parameters to the request address. Parameters are specified after the question mark ? and are separated by the ampersand &. 

Required parameters

  * cmd=vehadd — command to add a vehicle

  * account_id — contract number in the system

  * vehmodel — model of the monitoring device. The model ID is obtained from the response of the vehmodellist command.

  * imei — unique number of the monitoring device

  * type — type of vehicle. The vehicle type ID is obtained from the response of the vehtypelist command. If the required type is not in the list, a new ID can be specified.

  * name — state registration number or name of the vehicle

  * msisdn — number of the primary SIM card of the device

  * msisdn2 — number of the secondary SIM card of the device

  * mac — MAC address, identifier of the vehicle's device. If the mac parameter is specified, the system will automatically create a record for the vehicle in the "Buses" tab in the admin panel.

  * node — the number of the node where the command should be executed




Optional parameters:

  * folder — name of the folder for adding the vehicle. If the specified folder does not exist, it will be created. If no folder is specified, the vehicle will be added to the general list (root folder).

  * info — additional information about the vehicle

  * summer_fuel — fuel consumption in the summer period

  * winter_fuel — fuel consumption in the winter period

  * fuel_type — type of fuel used (50-diesel, 80-92-95-98-gasoline, 100-gas). If the parameter is not specified, the system will automatically set it to diesel.

  * lost_connection_time — time after which a loss of connection is recorded (in seconds)

  * time_zone — time zone of the vehicle. Default is set to Europe/Moscow.

  * initial_motor_hours — initial engine hour readings

  * driver_id — driver identifier

  * initial_mileage — initial mileage of the vehicle. If not specified, it is considered to start from zero.

  * speed_limit — maximum allowable speed. If not specified, speed control is disabled.

  * minsat — minimum number of satellites. Default is set to 4.

  * maxhdop — maximum HDOP. Default is set to 21.

  * mintime — minimum parking time for track splitting. Default is set to 3600 seconds.

  * maxspeed — maximum possible speed. Default is set to 250.

  * minspeed — minimum speed for detecting the start of movement. Default is set to 10 km/h.

  * minparking — minimum parking time on the route. Default is set to 300 seconds.

  * model — make and model of the vehicle

  * year — year of manufacture of the vehicle. If the year is not specified, it defaults to 1900.

  * vin — vehicle identification number

  * engine_horse — engine power

  * organization — name of the owning organization

  * column — column number

  * subdivision — subdivision




### Example request

| https://<server_address>/backend/api.php?cmd=vehadd&account_id=4019&type=1&name=testveh&imei=80987898789987&vehmodel=13&msisdn=7903&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "agent_id": "20518", "veh_id": "18994" }  
---|---  
  
In response to the API request, the following is returned:

  * code — response code indicating how the request was processed

  * msg — message with a textual description of the operation result

  * agent_id — identifier of the agent that processed the request

  * veh_id — identifier of the vehicle to which this response pertain

### Editing vehicle information — POST `vehedit`
This API is used to edit a vehicle’s data. You can update information such as type, model, license plate, VIN, year of manufacture, engine power, initial mileage, motor hours, and assign the vehicle to a folder, driver, or subdivision.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

Required:

  * cmd=vehedit — command to edit vehicle information

  * agentid — vehicle identifier or imei — unique device ID

  * node — the number of the node where the command should be executed




Optional:

  * type — vehicle type (ID from vehtypelist command)

  * veh_number — displayed name or license plate of the vehicle

  * veh_type — custom vehicle type (string)

  * folder_id — folder to assign the vehicle; if the folder does not exist, it will be created automatically. Default — root folder

  * model — vehicle model

  * initial_motor_hours — initial motor hours

  * driver_id — driver ID

  * initial_mileage — initial mileage (default 0)

  * year — year of manufacture (default 1900)

  * vin — vehicle VIN

  * engine_horse — engine power

  * organization — organization

  * column — column

  * subdivision — subdivision




### Example request

| https://<server_address>/backend/api.php?cmd=vehedit&agentid=144&node=1  
---|---  
  
Response

| { "Success": "The vehicle data has been changed" }  
---|---

### Moving a vehicle between accounts — GET `veh_move_account`
This API is used to move a vehicle between accounts.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

To obtain the required data, append parameters to the request address. Parameters are specified after the question mark ? and are separated by the ampersand &.

  * cmd=veh_move_account — command to move the vehicle to another account

  * vehicle_id — identifier of the vehicle that needs to be moved to the account

  * account_id — number of the new account

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=veh_move_account&vehicle_id=23&account_id=1005&node=1  
---|---  
  
Response 

| {"code": 1, "msg": "Success move vehicle 23 to account 1005"}  
---|---  
  
In response to the API request, the following is returned:

  * code — result code:

  * 1 — operation completed successfully

  * 0 — error occurred during the operation

  * msg — message with a textual description of the operation result  
---

### Vehicle information — GET `vehinfo`
This API is used to retrieve detailed information about a vehicle.

You can request data either by agent_id or by the device’s IMEI number.

The response returns full details, including license plate, fuel consumption, speed limits, VIN, model, configuration settings, assigned driver, and more.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

Required:

  * cmd=vehinfo — command to retrieve vehicle information

  * node — the number of the node where the command should be executed




One of these parameters must be specified:

  * agentid — vehicle identifier (agent_id)

  * imei — unique IMEI number of the device




### Example request:

| https://<server_address>/backend/api.php?cmd=vehinfo&agentid=81181&node=1  
---|---  
  
Response

| [ { "ownerid": 5374, "vehiclenumber": "Howen C", "typeid": 1, "summer_fuel": "10", "winter_fuel": "10", "idle_fuel": "2", "time_zone": "Europe/Moscow", "speed_limit": 0, "agentid": 81181, "account_id": 3925, "model": "", "year": "1900", "vin": "", "fuel_type": "50", "driver_name": "Test", "driver_phone": "12121212121" } ]  
---|---  
  
In response to the API request, the following is returned:

  * ownerid — ID of the owner

  * vehiclenumber — license plate number or vehicle name

  * typeid — vehicle type

  * summer_fuel / winter_fuel / idle_fuel — fuel consumption norms (summer, winter, idle)

  * time_zone — time zone where the vehicle is used

  * speed_limit — speed limit

  * account_id — account ID to which the vehicle is linked

  * model / year / vin — model, year of manufacture, and VIN of the vehicle

  * fuel_type — type of fuel

  * driver_name / driver_phone — name and phone number of the assigned driver

  * config — JSON with additional configuration (fuel settings, engine hours, restrictions, etc.)

### Account objects status — GET `vehicles`
This API provides a list of all vehicles linked to a specific account, along with their current status.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

Add the following parameters to your request URL:

  * cmd=vehicles — command to get the list of vehicles

  * account_id — the account ID for which you want to get the vehicle list

  * node — the number of the node where the command should be executed




Optional parameters:

  * is_show_deleted — show deleted vehicles

(0 — only active vehicles, 1 — all vehicles, including deleted ones)




Response format:

The response is a JSON array with vehicle data.

### Example request 

With deleted vehicles included:

| https://<server_address>/backend/api.php?cmd=vehicles&account_id=2238&is_show_deleted=1&node=1  
---|---  
  
Response

| { "data": [ { "active": 1, "deleted": 0, "agentid": 2914, "configuration": "Teltonika FM1100", "current_mileage": 69332, "dir": 0, "driver_name": "SSS", "driver_phone": "", "folder": "ЮФО", "lat": "47.200989", "lon": "39.634436", "model": "HYUNDAI IX35", "msisdn": "79818775160", "on": 1, "partner_price": "0.00", "price": "0.00", "sats": 7, "speed": 0, "ts": "1457709039", "type": "Static", "uniqid": "356307045913463", "vehiclenumber": "IX35" }, { "active": 0, "deleted": 1, "agentid": 8026, "configuration": "Teltonika FM4200", "current_mileage": 17441, "dir": 0, "driver_name": "", "driver_phone": "", "folder": "ЮФО", "lat": "47.318118", "lon": "39.995648", "model": "", "msisdn": "79110181596", "on": 1, "partner_price": "100.00", "price": "350.00", "sats": 9, "speed": 0, "ts": "1457726726", "type": "Car", "uniqid": "354330031297057", "vehiclenumber": "nex" } ] }  
---|---  
  
In response to the API request, the following is returned:

  * active — vehicle status: 1 = active, 0 = inactive

  * deleted — whether the vehicle is deleted: 0 = not deleted, 1 = deleted 

  * agentid — unique device ID

  * configuration — GPS device configuration name (e.g., Teltonika FM1100)

  * current_mileage — vehicle mileage, km

  * dir — direction of movement

  * driver_name — driver’s name (if assigned)

  * driver_phone — driver’s phone number

  * folder — folder/category name in the system

  * lat — latitude of the last known position

  * lon — longitude of the last known position

  * model — vehicle model

  * msisdn — SIM card number of the tracker

  * on — ignition status (1 = on, 0 = off)

  * partner_price — partner price

  * price — retail price

  * sats — number of satellites in view

  * speed — current speed, km/h

  * ts — timestamp (UNIX time) of the last position update

  * type — object type

  * uniqid — unique device identifier (usually IMEI)

  * vehiclenumber — vehicle number or label

### Vehicle type list — GET `vehtypelist`
This API is used to retrieve a list of all vehicle types in an account.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=vehtypelist — command to get the list of vehicle types

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=vehtypelist&node=1  
---|---  
  
Response

| { "code": 0, "data": [ { "identifier": 1, "name": "Car" }, { "identifier": 2, "name": "Truck" }, { "identifier": 3, "name": "Passenger" }, { "identifier": 4, "name": "Agrimotor" } ], "message": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — request result code (0 = successful)

  * data — array of vehicle types:

  * identifier — unique vehicle type ID

  * name — name of the vehicle type

  * message — text message with the result of the request

### Blocking or unblocking vehicles — POST `setvehblock`
This API allows you to lock or unlock vehicles based on the parameters agent_id, imei, or account_id. Depending on the status provided, the vehicle will either be locked or activated. Locking or unlocking can be performed using identifiers such as the agent, IMEI, or contract number.

## How to get data

### Request address

To get data, use the following address: https://<server_address>/backend/api.php?

### Method

POST

### Request parameters

Required:

• cmd=setvehblock — command to lock or unlock the vehicle

  * node — the number of the node where the command should be executed




• status — lock status. Values:

— 0 — locked

— 1 — active (unlocked)

One of these parameters must be specified:

• agentid — agent identifier

• imei — IMEI number of the device

• accountid — contract number

### Example requests

Lock vehicle by IMEI:

| https://<server_address>/backend/api.php?cmd=setvehblock&status=0&imei=1231231231&node=1  
---|---  
  
Unlock vehicle by agentid:

| https://<server_address>/backend/api.php?cmd=setvehblock&status=1&agentid=2914&node=1  
---|---  
  
Response

If the vehicle is successfully locked or unlocked, you will receive the following response:

| { "code": 0, "data": [ { "agentid": 2914, "status": 1 } ], "msg": "OK" }  
---|---  
  
The response to the API request will include:

• code — response code. Value:

— 0 — operation successful

— other possible values: errors like 400 or 500 if issues occurred.

• data — data about the lock/unlock operation

• agentid — agent identifier for whom the status was changed

• status — vehicle status:

— 0 — locked

— 1 — active (unlocked)

• msg — message indicating the result of the operation

### Raw vehicle data — GET `rawpoints`
This API returns raw GPS track data for a vehicle over a specified period.

Requests can only be made for periods of up to 10 days.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=rawpoints — command to get raw points

  * ts — start date in UNIX timestamp format

  * te — end date in UNIX timestamp format

  * agentid — vehicle identifier

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=rawpoints&ts=1760216400&te=1760302800&agentid=157773  
---|---  
  
Response

| { "code": 0, "data": [ { "agentid": 2914, "height": 32, "direction": 1, "latitude": "47.215545", "longitude": "39.706906", "satsinview": 15, "servertime": 1458044666, "speed": 10, "triggerdata": "Priority=0;EventSource=0;DIS1=1;GSMVal=4;IN1=67;Vsourse=14547;", "unixtimestamp": 1458022428 }, { "agentid": 2914, "height": 32, "direction": 339, "latitude": "47.215938", "longitude": "39.706751", "satsinview": 12, "servertime": 1458044666, "speed": 12, "triggerdata": "Priority=0;EventSource=0;DIS1=1;GSMVal=4;IN1=67;Vsourse=14538;", "unixtimestamp": 1458022437 } ], "deb": [ 2914, 1458022428, 1458043980 ], "message": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — request result code (0 = successful)

  * data — array of GPS points:

  * agentid — vehicle identifier

  * height/ altitude — altitude in meters

  * direction — movement direction in degrees

  * latitude/ longitude — coordinates of the point

  * satsinview — number of visible satellites

  * servertime — server time in UNIX timestamp

  * speed — speed in km/h

  * triggerdata — device trigger information

  * unixtimestamp — event time in UNIX timestamp

  * deb — array of debug information (agentid, start, and end of the period)

  * message — text message describing the result of the request

### Fuel сonsumption — GET `fuel`
This API retrieves fuel consumption data for a specific vehicle over a selected period. It returns information about refuels, fuel used, fuel drains, and fuel sensor readings at the beginning and end of the period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=fuel — command to retrieve fuel data

  * ts — start date of the period (Unix timestamp)

  * te — end date of the period (Unix timestamp)

  * agentid — vehicle ID (agent_id)  
node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=fuel&ts=1708981200&te=1709154000&agentid=6477&node=1  
---|---  
  
Response

| { "code": 0, "data": { "fill": 100,  "fuel": 84,  "stale": 0, "start": 27,  "stop": 43 }, "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code of the request (0 = successful)

  * fill — amount of fuel refilled during the period

  * fuel — amount of fuel consumed

  * stale — amount of fuel drained or lost

  * start — fuel sensor reading at the start of the period

  * stop — fuel sensor reading at the end of the period

  * msg — textual message with the request result

### Create a folder — POST `addfolder`
This API is used to create a new folder in the system. You can specify a parent folder, the name of the new folder, and user access rights.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

Required:

  * cmd=addfolder — command to create a folder

  * account_id — account ID

  * parent_id — ID of the parent folder

  * folder_name — name of the new folder

  * node — the number of the node where the command should be executed




Optional:

  * users — comma-separated list of user IDs to grant access to the folder

  * users=admins — grants access to all administrators of the account

If the parameter is missing or empty, the folder inherits access rights from the parent folder




### Example requests

Grant access to all administrators:

| https://<server_address>/backend/api.php?cmd=addfolder&account_id=5654&parent_id=654&folder_name=my_folder&users=admins&node=1  
---|---  
  
Grant access to specific users:

| https://<server_address>/backend/api.php?cmd=addfolder&account_id=5654&parent_id=654&folder_name=my_folder&users=123,212,432&node=1  
---|---  
  
Create a folder with default parent folder rights:

| https://<server_address>/backend/api.php?cmd=addfolder&account_id=5654&parent_id=654&folder_name=my_folder&node=1  
---|---  
  
Response

| { "success": "New folder my_folder has been created with ID 27330" }  
---|---

### Renaming a folder — POST `editfoldername`
This API allows you to change the name of an existing folder on the platform. To do this, you need to send a request with parameters indicating the folder whose name needs to be changed and the new name for it.  


## How to get data

### Request address

To get the data, use the address: https://<server_address>/backend/api.php

### Method

POST

### Request parameters

• cmd=editfoldername — command to change the folder name

  * node — the number of the node where the command should be executed




• folder_id — ID of the folder whose name needs to be changed

• new_folder_name — new name for the folder

### Example request

| https://<server_address>/backend/api.php?cmd=editfoldername&folder_id=454545&new_folder_name=testname&node=1  
---|---  
  
Response

| { "success": "Folder name successfully updated" }  
---|---

### List of folders — GET `getfolders`
This API is used to get the list of all folders available in the system. The response returns a list with unique folder IDs, their names, and their parent folders.

You can get either all folders or only those related to a specific account.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

Required:

  * cmd=getfolders— command to retrieve the list of folders

  * node — the number of the node where the command should be executed




Optional:

  * account_id— account ID for which you want to retrieve the list of folders




### Example request

Getting all folders:

| https://<server_address>/backend/api.php?cmd=getfolders&node=1  
---|---  
  
Getting folders for a specific account:

| https://<server_address>/backend/api.php?cmd=getfolders&account_id=3925  
---|---  
  
Response

| { "9793": {"name": "АС-Капитал", "parent": "Колонна №1"}, "11462": {"name": "Ленэнерго", "parent": "Колонна №1"}, "12551": {"name": "Вектор", "parent": "test123"}, "16453": {"name": "test_alex", "parent": "1april"}, "18492": {"name": "31Novfolder", "parent": "Колонна №1"} }  
---|---  
  
In response to the API request, the following is returned:

  * key (e.g., "9793") — unique folder ID

  * name — folder name

  * parent — parent folder to which the current folder belongs

### Deleting a folder — POST `deletefolder`
This API deletes a specified folder and moves all vehicles from it to the root folder.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=deletefolder — command to delete the folder

  * folder_id — identifier of the folder to be deleted

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=deletefolder&folder_id=545&node=1  
---|---  
  
Response

| { "success": "The folder has been successfully deleted" }  
---|---

### Module list — GET `modlist`
This API allows you to get the full list of available modules for an account, including their identifiers and descriptions.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/ax/api.php?

### Request parameters

  * cmd=modlist— command to retrieve the list of modules

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/ax/api.php?cmd=modlist&node=1  
---|---  
  
Response

| "code": 0, "data": [ { "descr": "Fuel Card Module", "identifier": 7, "name": "fuel" }, { "descr": "Engine Lock Module", "identifier": 8, "name": "lock" }, { "descr": "Notification Module", "identifier": 27, "name": "notification" } ], "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code— request result code (0 = successful)

  * data— array of module objects:

  * descr— module description

  * identifier— unique module ID

  * name— system name of the module

  * msg— text message describing the result of the request

### Equipment list — GET `vehmodellist`
This API is used to retrieve a list of all equipment types (device models) used in an account, including the manufacturer information.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/backend/api.php?

### Request parameters

  * cmd=vehmodellist — command to get the list of equipment models

  * node — the number of the node where the command should be executed




### Example request

| https://<server_address>/backend/api.php?cmd=vehmodellist&node=1  
---|---  
  
Response

| { "code": 0, "data": [ { "identifier": 1, "name": "ASC-6 GPS/GLONASS", "supplier": "APK COM" }, { "identifier": 2, "name": "ASC-6 Lite GPS/GLONASS", "supplier": "APK COM" } ], "message": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — request result code (0 = successful)

  * data — array of equipment models:

  * identifier — unique model ID

  * name — model name

  * supplier — equipment manufacturer

  * message — text message with the result of the request

### Working with Atom Linux commands — GET `atom_create_command`, `atom_delete_command`, `atom_get_all`, `atom_get_commands`
This article describes the main API commands that allow you to interact with Linux systems through the admin panel. With these commands, you can send, receive, delete, and view the history of commands for Atoms.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/backend/api.php

### List of commands

  * cmd=atom_get_all — get a list of sent commands

  * cmd=atom_get_commands — get a list of command templates

  * cmd=atom_create_command — send a Linux command

  * cmd=atom_delete_command — delete a Linux command

  * node — the number of the node where the command should be executed




## Get the list of sent Linux commands (command history)

This command allows you to retrieve a list of all commands that have been sent to the Atom. The history includes the Atom identifier, the command that was sent, and its execution status.

Method: GET

### Request parameters

  * cmd=atom_get_all — command for retrieving history

  * ident — unique Atom identifier (for example, b0:44:6t:0d:a9:04)




### Request example

| https://<server_address>/backend/api.php?cmd=atom_get_all&ident=b0:44:6t:0d:a9:04&node=1  
---|---  
  
Response example

| [ { "id": 27899, "agent_id": null, "ident": "8v:f5:8c:01:13:70", "script": "ls /root/", "processed": null, "ts": 1712138610, "result": null } ]  
---|---  
  
## Get the list of Linux command templates

This command allows you to retrieve a list of Linux command templates that can be used to send to an Atom. Templates contain a description and the command that will be executed on the device.

Method: GET

### Request parameters

  * cmd=atom_get_commands — command for retrieving command templates

  * ident — unique Atom identifier (for example, 80:c5:80:01:68:08)




### Request example

| https://<server_address>/backend/api.php?cmd=atom_get_commands&ident=80:c5:80:01:68:08  
---|---  
  
Response example

| [ { "id": 36, "command_name": "Video List", "description": null, "command": "ls -lsh /video/*.avi" } ]  
---|---  
  
## Send a Linux command

This command allows you to send a Linux command to the Atom. The command will be added to the queue and executed on the device.

Method: POST

### Request parameters

  * cmd=atom_create_command — command for creating a new command

  * ident — unique Atom identifier

  * script — script command (optional)




### Request example

| https://<server_address>/backend/api.php?cmd=atom_create_command&ident=b1:42:67:00:00:fd  
---|---  
  
Response example

| 27917 (ID of the command added to the queue)  
---|---  
  
## Delete a Linux command

If a command has not yet been executed, it can be removed from the queue using this method. Deletion is possible only before the command has been processed.

Method: GET

### Request parameters

  * cmd=atom_delete_command — command for deletion

  * ident— unique Atom identifier

  * command_id — ID of the command to delete




### Request example

| https://<server_address>/backend/api.php?cmd=atom_delete_command&ident=b0:44:6f:0d:av:88&command_id=27921  
---|---  
  
Response example

| "Success delete"  
---|---  
  
## API error codes

  * 400 Bad request — invalid data format or a required parameter is missing.

Possible messages:

  * {"error": "Missing ident param"} — Atom identifier is missing

  * {"error": "Command already processed"} — the command has already been executed

  * {"error": "Unknown macro: {Unknown macro}"} — unknown macro command

  * 500 Internal server error — internal server error




## Interaction with commands in the interface

In the PILOT interface, interaction with Atoms takes place through the admin panel tab "Autoconductor → Buses", where the "Interact" command is available.

Through this function you can:

  * Send commands (Linux commands) to the Atom

  * View the list of available commands (templates)

  * Display the history of all sent commands

  * Access the result of each executed command

### Managing rental contracts — GET 
This API provides functionality for managing vehicle rental contracts. With this API, you can start, update, stop rentals, as well as authenticate and generate tokens for authorization.

## Authorization

To use the API, authentication is required with a Bearer token.

### Getting an authorization token

Before sending requests, you need to obtain a token by generating it using the login and password for the admin panel.

### Authorization example

Example request to generate a token:

| curl --location --request GET 'https://adm.pilot-gps.africa/backend/app/contracts.php' \ \--header 'Content-Type: application/json' \ \--data-raw '{ "cmd": "generate_token", "login": "YOUR_LOGIN_FOR_ADMIN_PANEL", "password": "YOUR_PASSWORD_FOR_ADMIN_PANEL" }'  
---|---  
  
Example response:

| { "code": 0, "odo": "0", "message": "007898667a1b5711682399ea38a84f61" }  
---|---  
  
You will receive a token in the response. Use it in the Authorization header for further requests.

Example header:

| Authorization: Bearer 007898667a1b5711682399ea38a84f61  
---|---  
  
## Main commands

To perform operations, specify the cmd parameter, which defines which operation you want to perform:

  * generate_token — get token for authorization

  * start— start vehicle rental

  * update — update rental details

  * stop — stop vehicle rental




## Request parameters

All parameters are sent in JSON format.

Parameter |  Type |  Required |  Description  
---|---|---|---  
mva |  int |  Yes |  Numeric ID of the rented vehicle  
ra |  int |  Yes |  Rental agreement number  
plate_number |  string |  Yes |  Vehicle plate number  
driver_name |  string |  Yes |  Name of the driver renting the vehicle  
driver_phone |  string |  Yes |  Driver's phone number  
driver_passport |  string |  No |  Driver's passport  
driver_address |  string |  No |  Driver's address  
driver_license |  string |  No |  Driver's license number  
driver_license_exp |  string |  No |  Driver's license expiry date  
driver_email |  string |  No |  Driver's email address  
driver_birth_date |  string |  No |  Driver's birth date  
driver_sex |  string |  No |  Gender (m or f)  
driver_country |  string |  No |  Driver's country  
driver_rating |  int |  No |  Driver's rating  
ts_expected |  int |  Yes  |  Expected rental start time (Unix timestamp)  
te_expected |  int |  Yes |  Expected rental end time (Unix timestamp)  
ts_real |  int |  No |  Actual rental start time (Unix timestamp)  
te_real |  int |  No |  Actual rental end time (Unix timestamp)  
start_location |  object |  Yes |  Rental start location (with latitude, longitude or address)  
end_location |  object |  Yes |  Rental end location (latitude, longitude or address)  
rate_code |  string |  No |  Rental rate code  
car_group_charged |  string |  No |  Vehicle group for charging  
checkout_branch |  string |  No |  Checkout branch  
mileage_limit |  int |  No |  Mileage limit  
cid |  string |  No |  Client ID (driver renting the vehicle)  
  
## Example requests

### Start rental

| curl --location --request POST 'https://adm.pilot-gps.africa/backend/app/contracts.php' \ \--header 'Content-Type: application/json' \ \--header 'Authorization: Bearer 007898667a1b5711682399ea38a84f61' \ \--data-raw '{ "cmd": "start", "mva": 111, "ra": 67890, "plate_number": "ABC123", "driver_name": "John Doe", "driver_phone": "123-456-7890", "ts_expected": 1644927600, "te_expected": 1644981600, "start_location": { "lat": 40.712776, "lon": -74.005974 }, "car_group_charged": "Economy" }'  
---|---  
  
Response

| { "code": 0, "odo": "1233", "message": "Success" }  
---|---  
  
The response includes:

  * code— response code

  * odo— odometer value

  * message— message with the request result




### Update rental

| curl --location --request POST 'https://adm.pilot-gps.africa/backend/app/contracts.php' \ \--header 'Authorization: Bearer 007898667a1b5711682399ea38a84f61' \ \--header 'Content-Type: application/json' \ \--data-raw '{ "cmd": "update", "ra": 67890, "plate_number": "ABC123", "driver_name": "John Doe", "driver_phone": "123-456-7890", "mileage_limit": 2000 }'  
---|---  
  
Response

| { "code": 0, "odo": "1208607", "message": "Success" }  
---|---  
  
### Stop rental

| curl --location --request POST 'https://adm.pilot-gps.africa/backend/app/contracts.php' \ \--header 'Authorization: Bearer YOUR_TOKEN' \ \--header 'Content-Type: application/json' \ \--data-raw '{ "cmd": "stop", "ra": 67890, "driver_rating": 4, "end_location": {"address": "Ilino 2c"} }'  
---|---  
  
Response

| { "code": 0, "odo": "1208607", "message": "Success" }  
---|---  
  
## Response and error codes

0— Operation successful

1— Vehicle not found

2— No changes to update

3— Rental agreement not found

4— Authentication error

5— Unknown error

6— Insufficient rights to perform operation

7— Contracts module not active

8— This rental agreement number is already in use by another account

9— Vehicle rented by another account

10— Vehicle not rented

11— Incorrect request

12— Invalid location parameter

13— This rental agreement number is used by another agent

14— Passport was provided, but driver's name not specified

15— Driver's name provided, but passport not specified

16— Driver not found with provided details

17— Driver details do not match previously saved data

18— Rental agreement with this number not found

19— This rental agreement has already ended

20— Vehicle already rented

21— Incorrect driver specified

22— Existing contract closed, new one created

500— Internal server error



## User API v.2 (`/api/api.php`)

### Vehicle list — GET `list`
This API provides comprehensive information about vehicles, including their current location, sensor data, technical specifications, and extra parameters.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php? 

### Request parameters

To obtain the required data, append the command to the request address.

  * cmd=list — command to retrieve the list of vehicles.

  * node — the number of the node where the command should be executed




The format of the requested data is an array of vehicle data.

### Example request

| https://<server_address>/api/api.php?cmd=list&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "list": [ { "agentid": 9003, "imei": "356307046873054", "typeid": 1, "type": "Car", "vehiclenumber": "Х444МР123", "vin": "TRDFG65876", "folder": "Geo-Center OOO", "created_time": 1414224633, "current_mileage": 881, "status": { "unixtimestamp": "1418744535", "lat": "43.5562", "lon": "39.9084", "speed": 0, "dir": 268, "alt": 246, "satsinview": 16 }, "extra_params": { "kmlimit": "2", "mvanumber": "12312", "make_model": "BMW" }, "sensors": [ { "name": "Parking", "description": "TEST SPEED" }, { "name": "Fuel sensor", "description": "Fuel sensor" }, { "name": "External power supply", "description": "External power supply" }, { "name": "Ignition sensor", "description": "Ignition sensor" } ], "sensors_status": [ { "name": "Ignition sensor", "id": "1187852", "hum_value": "off", "dig_value": "0", "raw_value": "0", "change_ts": "1627467122", "group": "" }, { "name": "External power supply", "id": "1187851", "hum_value": "26.27 V", "dig_value": "26.27", "raw_value": "26272", "change_ts": "1627467122", "group": "" }, { "name": "Fuel sensor", "id": "1187850", "hum_value": "1 l", "dig_value": "1", "raw_value": "1", "change_ts": "1626336197", "group": "" } ] } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — status code (0 indicates success)

  * msg — status message

  * list — an array of vehicle objects, where each object contains:

  * agentid — unique identifier of the tracking device

  * imei — international Mobile Equipment Identity

  * typeid — numeric identifier of the vehicle type

  * type — type of vehicle

  * vehiclenumber — vehicle registration number

  * vin — vehicle Identification Number

  * folder — organizational group

  * created_time — time the vehicle was added to the system (in Unix timestamp format)

  * current_mileage — current mileage

  * status — current status information, including:

  * unixtimestamp — time of the latest update

  * lat — latitude

  * lon — longitude

  * speed — speed

  * dir — direction of movement (in degrees)

  * alt — altitude above sea level

  * satsinview — number of visible GPS satellites

  * extra_params — additional vehicle parameters. These may vary depending on configuration and object type, and may include:

  * kmlimit — mileage limit

  * mvanumber — vehicle number

  * make_model — make and model

  * sensors — array of available sensors

  * sensors_status — detailed status for each sensor, including:

  * name — sensor name

  * id — sensor identifier

  * hum_value — calibrated human-readable value

  * dig_value — calibrated digital value

  * raw_value — raw, uncalibrated value

  * change_ts — timestamp of the last value change

  * group — sensor group

### List of objects — POST 
This API provides information about vehicles, including their current location.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/api/CRIT/api.php?node=<node_id>

### Request parameters

To receive the data, you must send an authorized request and specify the function:

  * Username — user login

  * Password — user password

  * functionName=api_objectlist — command to get the list of objects

  * node — the node number where the command should be executed




Response format: an array of vehicle objects.

### Example request

| https://<server_address>/api/CRIT/api.php?node=6 Content-Type: multipart/form-data Username=TestName Password= 123456 functionName=api_objectlist  
---|---  
  
Response

| [ { "IMEI": "352016704092097", "PLATE": "5209", "NAME": "", "LATITUDE": 29.7682433, "LONGITUDE": 39.9979749 }, { "IMEI": "352016703961657", "PLATE": "6561", "NAME": "", "LATITUDE": 25.9131066, "LONGITUDE": 46.4645949 } ]  
---|---  
  
The API response returns an array of vehicle objects. Each object contains:

  * IMEI — identifier of the tracker installed on the vehicle

  * PLATE — vehicle license plate number

  * NAME — vehicle name

  * LATITUDE — current latitude of the vehicle location

  * LONGITUDE — current longitude of the vehicle location

### Finding the nearest vehicles — GET `get_nearest_vehicles`
This API allows you to search for vehicles within a specified radius from a given point, sorted by distance.

It is useful for rapid response scenarios (e.g., police, emergency services), where operators need to quickly determine which vehicles are closest to an incident location.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php? 

### Request parameters

To get the required data, add the following parameters to the URL:

  * cmd=get_nearest_vehicles— command to get nearest vehicles

  * group_id— ID of the vehicle group (orgdep.id)

  * lat— latitude of the target point (from −90 to 90)

  * lon— longitude of the target point (from −180 to 180)

  * radius— search radius. Supports values like 500M, 1KM, 10KM, 20KM, or a numeric value in meters




### Example request

| https://<server_address>/api/api.php?cmd=get_nearest_vehicles&group_id=228&lat=43.28191&lon=76.90723&radius=50KM  
---|---  
  
Response

| { "code": 0, "msg": "OK", "group_id": 123, "group_name": "Police Fleet", "location": { "latitude": 24.4539, "longitude": 54.3773 }, "radius_meters": 10000, "vehicles_found": 2, "vehicles": [ { "vehiclenumber": "POL-001", "agentid": 456, "veh_id": 789, "imei": "123456789", "model": "Toyota Land Cruiser", "vehicle_type": "Car", "location": { "address": "Sheikh Zayed Road, Dubai, UAE", "latitude": 24.4550, "longitude": 54.3780, "altitude": 10 }, "status": { "active": 1, "speed": 0, "direction": 0, "altitude": 10, "satsinview": 12, "ignition": 1, "unixtimestamp": 1706964000, "zone": [] }, "distance": { "meters": 1234, "kilometers": 1.23, "straight_line_meters": 1200 }, "travel_time": { "seconds": 180, "minutes": 3.0, "formatted": "3 min" } } ] }  
---|---  
  
In response to the API request, the following is returned:

  * group_id — ID of the vehicle group

  * group_name— name of the vehicle group

  * location— coordinates of the target point

  * latitude — latitude

  * longitude — longitude

  * radius_meters — search radius in meters

  * vehicles_found — number of vehicles found

  * vehicles — array of vehicles with details:

  * vehiclenumber — vehicle number

  * agentid — agent/device ID

  * veh_id — vehicle ID

  * imei — device IMEI

  * model — vehicle model

  * vehicle_type — vehicle type (Car, Truck, etc.)

  * location — vehicle location

  * address — address (from geocoder)

  * latitude, longitude, altitude

  * status — current vehicle status

  * active — active status (1 = active)

  * speed — speed in km/h

  * direction — movement direction

  * altitude — altitude

  * satsinview — number of satellites in view

  * ignition — ignition status (1 = on)

  * unixtimestamp — event timestamp in UNIX format

  * zone — array of active geofences

  * distance — distance to target

  * meters — distance in meters

  * kilometers — distance in kilometers

  * straight_line_meters — straight-line distance in meters

  * travel_time — estimated travel time to target

  * seconds — in seconds

  * minutes — in minutes

  * formatted — formatted string, e.g., "3 min"

### Object information — POST 
This API provides detailed information about a specific vehicle.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/api/CRIT/api.php?node=<node_id>

### Request parameters

To receive the data, you must send an authorized request and specify the function and the object:

  * Username — user login

  * Password — user password

  * functionName=api_objectdetails — command to get object details

  * parameters — IMEI of the object for which details are requested

  * node — the node number where the command should be executed




Response format: a single vehicle object.

### Example request

| POST https://<server_address>/api/CRIT/api.php?node=6 Content-Type: multipart/form-data Username=TestName Password= 123456 functionName=api_objectdetails parameters=352217706092097  
---|---  
  
Response

| { "IMEI": "352016704092097", "PLATE": "5209 ", "INSTALLATIONDATE": "Dec 06, 2023", "NAME": "", "LATITUDE": 29.7682433, "LONGITUDE": 39.9979749 }  
---|---  
  
The API response returns an object with vehicle information. Each field contains:

  * IMEI — identifier of the tracker installed in the vehicle

  * PLATE — vehicle license plate number

  * INSTALLATIONDATE — date when the tracker was installed in the vehicle

  * NAME — vehicle name

  * LATITUDE — current latitude of the vehicle location

  * LONGITUDE — current longitude of the vehicle location

### Object history — POST 
This API returns the movement history of a vehicle for a specified period. It provides tracks with information about mileage, operating time, stops, start and end coordinates, and more.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/api/CRIT/api.php?node=<node_id>

### Request parameters

To retrieve the data, you must send an authorized request and specify the function and parameters:

  * Username — user login

  * Password — user password

  * functionName=api_objecthistory — command to get the object history

  * parameters — a parameter string in the following format:

IMEI,FROM_DATETIME,TO_DATETIME

where:

  * IMEI — object IMEI

  * FROM_DATETIME — start date and time of the period

  * TO_DATETIME — end date and time of the period




Response format: an array of object tracks for the specified period.

### Example request

| POST https://<server_address>/api/CRIT/api.php?node=6 Content-Type: multipart/form-data Username=TestName Password= 123456 functionName=api_objecthistory parameters=352016704092097,2025-11-21 04:07:03,2025-11-23 04:07:03  
---|---  
  
Response

| [ { "FLCNSMD": 0, "ENDTM": "2025-11-21 19:05:30", "MILEGND": 106286.11, "ENDLCTN": "Sakaka, Al Jawf Region, 3628, Saudi Arabia", "IDLDRTN": "00:00:00", "CNT": 1, "WRKNGDRTN": "07:47:22", "MILEGN": 826.37, "DRVR": "", "startlatitude": 24.399892, "OBJTID": 1344487, "WRKNGSTRTTM": "2025-11-21 11:18:08", "endlongitude": 48.20568, "startlongitude": 39.644265, "STPDRTN": "00:12:28", "DY": "2025-11-21", "endlatitude": 29.960238, "OBJCTNME": "5209 ب د م", "WRKNGSTRTLCTN": "Sakaka, Al Jawf Region, 3628, Saudi Arabia", "MXSPDP": 136 } ]  
---|---  
  
The API response returns an array of tracks for the specified period. Each track object contains the following fields:

  * FLCNSMD — fuel consumption within this track

  * ENDTM — track end time

  * MILEGND — total mileage at the end of the track

  * ENDLCTN — address of the track end point

  * IDLDRTN — total idle time within this track

  * CNT — track sequence number (index) for the day

  * WRKNGDRTN — total engine operating time / ignition ON time

  * MILEGN — mileage covered within this track

  * DRVR — driver name

  * startlatitude — latitude of the track start point

  * startlongitude — longitude of the track start point

  * endlatitude — latitude of the track end point

  * endlongitude — longitude of the track end point

  * OBJTID — internal object identifier

  * WRKNGSTRTTM — time of the first ignition ON within this track

  * STPDRTN — total stop duration within the track

  * DY — track date

  * OBJCTNME — object name

  * WRKNGSTRTLCTN — address of the track start point

  * MXSPDP — maximum speed reached in this track

### Current vehicle status — GET `status`
This API is used to obtain the current status information of one or more vehicles, including data on location, speed, sensor readings, and technical condition.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

To obtain the required data, append parameters to the request address. Parameters are specified after the question mark ? and are separated by the ampersand &.

  * cmd=status — command to retrieve status information

  * imei — unique identifier of the GPS tracker

  * agents — list of agent IDs, specified as a comma-separated list to request statuses of multiple vehicles

  * veh_numbers — registration number of the vehicle, exactly as it appears in the system, with strict adherence to letter and number case

  * node — node number where the command is executed




| At least one of the following parameters must be present in the request: imei, agents, or veh_numbers.  
---|---  
  
## Examples

### Request by IMEI

| https://<server_address>/api/api.php?cmd=status&imei=357073296325265&node=1  
---|---  
  
### Request by multiple agent IDs

| https://<server_address>/api/api.php?cmd=status&agents=51594,44841&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": [ { "agentid": 44841, "imei": "865473034076573", "configuration": "Teltonika FM2200", "typeid": 27, "type": "Car", "vehiclenumber": "NURKA", "folder": "REAL", "created_time": 1518167398, "uniqid": "865473034076573", "current_mileage": 65345, "initial_mileage": 0, "driver_name": null, "driver_phone": null, "model": "ВАЗ (Lada) Kalina", "info": " test", "vin": "XTA219470K0259832", "status": { "active": 1, "speed": 0, "direction": 27, "lat": "47.119755", "lon": "39.667492", "alt": 0, "satsinview": 16, "unixtimestamp": "1621432378", "moving": 0, "parking": 9267, "firing": 0 }, "sensors_status": [ { "name": "Ignition sensor", "id": "150549", "hum_value": "выкл.", "dig_value": "0", "raw_value": "12494", "change_ts": "1621423461", "group": "GROUP!" }, { "name": "Датчик топлива", "id": "368013", "hum_value": "1249.4 -", "dig_value": "1249.4", "raw_value": "12494", "change_ts": "1621432378", "group": "myGroup" } ] } ], "reqest_time": 0.0642 }  
---|---  
  
The response is returned in JSON format and contains:

  * imei — unique number of the tracker

  * distance — distance traveled during the specified period

  * agent_id — identifier of the tracking device

  * account_id — account number in the system

  * code — status code (0 indicates success)

  * msg — message about the status of the request

  * data — array of objects containing information about the vehicles:

  * agentid — contract identifier

  * imei — International Mobile Equipment Identity

  * vin — vehicle identification number

  * configuration — model of the tracker

  * typeid — numerical identifier of the vehicle type

  * type — type of vehicle

  * vehiclenumber — registration number of the vehicle

  * folder — organizational group or branch

  * created_time — creation time in Unix timestamp format

  * uniqid — unique identifier

  * current_mileage — current mileage

  * initial_mileage — initial mileage

  * driver_name — name of the driver

  * driver_phone — phone number of the driver

  * model — model of the vehicle

  * info — additional information

  * status — information about the current status:

  * active — whether the object is active (1 for yes, 0 for no)

  * speed — current speed

  * direction — current direction in degrees

  * lat — current latitude

  * lon — current longitude

  * alt — current altitude

  * satsinview — number of visible satellites

  * unixtimestamp — time of the last update

  * moving — time spent moving in seconds

  * parking — time spent parked in seconds

  * firing — ignition status (1 for on, 0 for off)

  * sensors_status — array containing information about the sensors:

  * name — name of the sensor

  * id — identifier of the sensor

  * hum_value — actual value after calibration

  * dig_value — digital value after calibration

  * raw_value — raw value before calibration

  * change_ts — time of the last value change in Unix timestamp format

  * group — sensor group

  * request_time — time taken to process the request in seconds

### Daily vehicle summary — GET `vehinfo_24_hours`
This API retrieves data about a vehicle over the past 24 hours, including mileage, fuel level, refueling, and fuel consumption.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=vehinfo_24_hours — command to get 24-hour vehicle info

  * agent_id — vehicle ID (can specify multiple IDs separated by commas)

  * imei — device IMEI (can specify multiple IMEIs separated by commas)

  * ts — timestamp (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=vehinfo_24_hours&imei=10518,165182&ts=1617710825&node=1  
---|---  
  
Response

| { "10518": { "total_mileage": 745851.44, "fuel_start": 229.37, "fuel_stop": 229.37, "fuel_fill": 409.6, "fuel_drain": 153.15, "fuel_consumption_l": 256.45, "fuel_consumption_l_per_100km": 35, "fuel_consumption_norm_l": 161.5658, "fuel_consumption_norm_l_per_100km": 22, "engine_hours": 0 }, "165182": { "total_mileage": 100946.68, "fuel_start": 0, "fuel_stop": 0, "fuel_fill": 0, "fuel_drain": 0, "fuel_consumption_l": 0, "fuel_consumption_l_per_100km": 0, "fuel_consumption_norm_l": 22.313, "fuel_consumption_norm_l_per_100km": 10, "engine_hours": 0 } }  
---|---  
  
In response to the API request, the following is returned:

  * total_mileage — total mileage

  * fuel_start — fuel level at the start of the period

  * fuel_stop — fuel level at the end of the period

  * fuel_fill — fuel added (refueling)

  * fuel_drain — fuel removed (draining)

  * fuel_consumption_l — actual fuel consumed (liters)

  * fuel_consumption_l_per_100km — fuel consumption per 100 km

  * fuel_consumption_norm_l — normative fuel consumption (liters)

  * fuel_consumption_norm_l_per_100km — normative fuel consumption per 100 km

  * engine_hours — engine hours

### Link contract to vehicle — GET `link_contract`
This API links a contract to a vehicle, specifying its license plate, contract start date, contract name, and distance.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=link_contract — command to link the contract

  * PlateNum — vehicle license plate number

  * Date — contract start date (Unix timestamp)

  * Name — contract name

  * Distance — distance (e.g., mileage under the contract)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=link_contract&PlateNum=test12345&Distance=1111&Date=1623927270&Name=1212&node=1  
---|---  
  
Response

| { "code": 0, "msg": "The linking is successful" }  
---|---  
  
In response to the API request, the following is returned:

  * code— result code (0 = success)

  * msg— server message confirming the action

### Unlink contract from vehicle — DELETE `unlink_contract`
This API unlinks a contract from a vehicle.

## How to get data

### Method

DELETE

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=unlink_contract — command to unlink the contract

  * PlateNum — vehicle license plate number

  * node — node number where the command should be executed (optional)




### Example request

| https://<server_address>/api/api.php?cmd=unlink_contract&PlateNum=test12345&node=1  
---|---  
  
Response

| { "code": 0, "msg": "Deletion is successful" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message about the result of the action

### Update vehicle custom fields — POST `agent_update_custom_fields`
This API updates a vehicle’s custom [fields](<vehicle_field_editor.html>) in a single request by agent_id or imei. You can update all fields or just a subset; the number of fields is not limited.

Method

POST

### Request address

To get the data, use the address: https://<server_address>/api/api.php

### Headers

Content-Type: application/json

Authorization: Basic <your_credentials_b64>

### Request parameters

  * cmd=agent_update_custom_fields — API command

  * agent_id — vehicle identifier (use if you don’t send imei)

  * imei — device IMEI (use if you don’t send agent_id)

  * custom_fields — object with key–value pairs for updating custom fields




In custom_fields you can include any number of fields, e.g., extra_field1, extra_field2, … extra_fieldN (as long as these fields exist in the account). Values may be numbers, strings, or booleans.

### Example requests

Update multiple fields by agent_id:

| curl -X POST 'https://<server_address>/api/api.php' -H 'Content-Type: application/json' -H 'Authorization: Basic <your_credentials_b64>' -d '{ "cmd": "agent_update_custom_fields", "agent_id": 30547, "custom_fields": { "extra_field1": "Waybill #123", "extra_field2": "2025-11-01", "extra_field7": "+79000000000" } }'  
---|---  
  
Update by imei:

| curl -X POST 'https://<server_address>/api/api.php' -H 'Content-Type: application/json' -H 'Authorization: Basic <your_credentials_b64>' -d '{ "cmd": "agent_update_custom_fields", "imei": "359339099999999", "custom_fields": { "extra_field3": "Pass A12345", "extra_field4": "2025-12-31" } }'  
---|---  
  
### Example response

| { "code": 1, "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — execution code: 1 = success, 0 = error

  * msg — textual result (e.g., "OK" or an error message)

### Mileage and fuel level — GET `istatus`
This API gets information about a vehicle’s mileage and fuel level at a specific moment in time.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=istatus — API command to get the status

  * imei — unique vehicle identifier in PILOT

  * unixtimestamp — timestamp for the requested moment (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=istatus&unixtimestamp=1408840780&imei=356495042533101&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "total_run": 0, "total_run_by_can": 0, "engine_hours": 0, "fuel_sensors": [ { "info": "Fuel Sensor 1", "id": 150325, "fieldname": "t_53lls1", "fuel": 0 }, { "info": "Fuel Sensor 2", "id": 150326, "fieldname": "lls2", "fuel": 0 } ], "fuel": 0, "unixtimestamp": 1408840780 }  
---|---  
  
In response to the API request, the following is returned:

  * total_run — total mileage of the vehicle at the requested time (km)

  * total_run_by_can — mileage according to CAN bus data (km)

  * engine_hours — engine hours in seconds

  * fuel — fuel level in the tank at the requested time (liters)

  * fuel_sensors — array of fuel sensors (if multiple sensors exist), each containing:

  * info — sensor description

  * id — unique sensor ID

  * fieldname — system field name of the sensor

  * fuel — fuel level recorded by this sensor (liters)

  * unixtimestamp — timestamp for which the data is returned (Unix timestamp)

### Mileage for selected period — GET `istatus`
This API returns the mileage and engine hours of a vehicle within the selected time range.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET

### Request parameters

  * cmd=istatus — command to get mileage

  * imei — object identifier in the system

  * start — start of the interval (Unix timestamp)

  * stop — end of the interval (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=istatus&imei=6794i&start=1664917200&stop=1665003600&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "run": 126.79500000000007, "run_by_can": 0, "motorhours": 9897, "unixtimestamp_start": 1664917200, "unixtimestamp_stop": 1665003600 }  
---|---  
  
In response to the API request, the following is returned:

  * run — mileage over the period, km

  * run_by_can — mileage from CAN data, km

  * motorhours — engine hours over the period, seconds

  * unixtimestamp_start — start of the interval (Unix timestamp)

  * unixtimestamp_stop — end of the interval (Unix timestamp)

### Trip statistics and distance — GET `distance`
This API provides information about mileage, trips, and parkings of a vehicle for a specified time period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=distance — API command to get mileage data

  * imei — unique identifier of the vehicle/device

  * start — start time of data collection (Unix timestamp)

  * stop — end time of data collection (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=distance&imei=7157153151020&start=1676926800&stop=1677013200&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "distance": { "duration": 23740, "length": 104.54, "start": 1761944400, "stop": 1762030800, "can": 0, "usecan": false, "gps": 104.54, "parking_time": 62237, "parking_count": 14, "max_speed": 92, "avg_speed": 18, "trips_cnt": 6, "trips_ts": 1761947653, "trips_te": 1762027933, "trips_time": 80280, "trips_driving": 18043, "parkings": { "1761948742": { "ts": 1761948742, "te": 1761949164, "lat": "25.404495", "lon": "55.443546", "track_id": 341967622 }, "1761950225": { "ts": 1761950225, "te": 1761978656, "lat": "25.380997", "lon": "55.434662" }, "1761978976": { "ts": 1761978976, "te": 1761979445, "lat": "25.386534", "lon": "55.439198", "track_id": 342008717 }, "1761983958": { "ts": 1761983958, "te": 1761984933, "lat": "25.386375", "lon": "55.413776", "track_id": 342008717 }, "1761986309": { "ts": 1761986309, "te": 1761988132, "lat": "25.341892", "lon": "55.397186", "track_id": 342008717 }, "1761988857": { "ts": 1761988857, "te": 1761989297, "lat": "25.368885", "lon": "55.42438", "track_id": 342008717 }, "1761989685": { "ts": 1761989685, "te": 1762002192, "lat": "25.380968", "lon": "55.434662" }, "1762002484": { "ts": 1762002484, "te": 1762002826, "lat": "25.378464", "lon": "55.442036", "track_id": 342062148 }, "1762003344": { "ts": 1762003344, "te": 1762003645, "lat": "25.381042", "lon": "55.434467", "track_id": 342062148 }, "1762005988": { "ts": 1762005988, "te": 1762006366, "lat": "25.316278", "lon": "55.382927", "track_id": 342062148 }, "1762007656": { "ts": 1762007656, "te": 1762008203, "lat": "25.354523", "lon": "55.382133", "track_id": 342062148 }, "1762010014": { "ts": 1762010014, "te": 1762012025, "lat": "25.381067", "lon": "55.434717" }, "1762012439": { "ts": 1762012439, "te": 1762021038, "lat": "25.369600", "lon": "55.435860" }, "1762022306": { "ts": 1762022306, "te": 1762027298, "lat": "25.380917", "lon": "55.434715" } }, "tracks": { "341967622": { "start": 1761947653, "stop": 1761950225, "ts": 1761947653, "te": 1761950225, "length": 22.83, "can": null, "gps": 22.83, "max_speed": 92, "avg_speed": 26, "parkings": [1761948742], "parking_count": 1, "parking_time": 422, "startlat": "25.381645", "stoplat": "25.380997", "startlon": "55.528587", "stoplon": "55.434662" }, "342008717": { "start": 1761978656, "stop": 1761989685, "ts": 1761978656, "te": 1761989685, "length": 43.99, "can": null, "gps": 43.99, "max_speed": 72, "avg_speed": 18, "parkings": [1761978976, 1761983958, 1761986309, 1761988857], "parking_count": 4, "parking_time": 3707, "startlat": "25.380960", "stoplat": "25.380968", "startlon": "55.434743", "stoplon": "55.434662" }, "342062148": { "start": 1762002192, "stop": 1762010014, "ts": 1762002192, "te": 1762010014, "length": 28.78, "can": null, "gps": 28.78, "max_speed": 61, "avg_speed": 14, "parkings": [1762002484, 1762003344, 1762005988, 1762007656], "parking_count": 4, "parking_time": 1568, "startlat": "25.381003", "stoplat": "25.381067", "startlon": "55.434752", "stoplon": "55.434717" }, "342078382": { "start": 1762012025, "stop": 1762012439, "ts": 1762012025, "te": 1762012439, "length": 2.32, "can": null, "gps": 2.32, "max_speed": 34, "avg_speed": 19, "parkings": [], "parking_count": 0, "parking_time": 0, "startlat": "25.381067", "stoplat": "25.369600", "startlon": "55.434717", "stoplon": "55.435860" }, "342089059": { "start": 1762021038, "stop": 1762022306, "ts": 1762021038, "te": 1762022306, "length": 3.97, "can": null, "gps": 3.97, "max_speed": 49, "avg_speed": 11, "parkings": [], "parking_count": 0, "parking_time": 0, "startlat": "25.369557", "stoplat": "25.380917", "startlon": "55.435802", "stoplon": "55.434715" }, "342095630": { "start": 1762027298, "stop": 1762027933, "ts": 1762027298, "te": 1762027933, "length": 2.65, "can": null, "gps": 2.65, "max_speed": 32, "avg_speed": 13, "parkings": [], "parking_count": 0, "parking_time": 0, "startlat": "25.380903", "stoplat": "25.380952", "startlon": "55.434485", "stoplon": "55.434668" } }, "startlat": "25.381645", "startlon": "55.528587", "stoplat": "25.380952", "stoplon": "55.434668", "active_days": 1, "range_dates": { "1761944400": 1 } } }  
---|---  
  
In response to the API request, the following is returned:

  * duration — total trip duration in seconds

  * length — actual distance traveled in kilometers

  * max_speed — maximum speed in km/h

  * avg_speed — average speed in km/h

  * trips_cnt — number of trips

  * trips_time — total trip time in seconds

  * trips_driving — time spent driving without stops in seconds

  * parking_count — number of parking events

  * parking_time — total parking time in seconds

  * parkings — an array of parking events, each parking event includes:

  * ts — parking start time

  * te — parking end time

  * lat — latitude

  * lon — longitude

  * length — parking duration in kilometers

  * track_id — track identifier associated with the parking event. If the parking is linked to a track, this field will contain a unique track ID.

  * tracks — an array of trip data, each trip includes:

  * length — trip distance

  * max_speed — maximum speed

  * avg_speed — average speed

  * startlat, startlon, stoplat, stoplon — coordinates of the start and end points of the trip

### Odometer and fuel for selected period — GET `odo_and_fuel`
This API retrieves information about vehicle mileage (odometer readings) and fuel consumption over a selected time interval.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET 

### Request parameters

  * cmd=odo_and_fuel — command to fetch odometer and fuel data

  * imei — device identifier (object ID)

  * start — start time of the period (Unix timestamp)

  * stop— end time of the period (Unix timestamp)

  * node — node number on which the command is executed




Example request

| https://<server_address>/api/api.php?cmd=odo_and_fuel&start=1767214800&stop=1767560400&imei=861076084529922&node=6  
---|---  
  
Response

| { "code": 0, "msg": "ok", "data": { "fuel": 7.6, "start_odo": 407121.6, "stop_odo": 407229.4 } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message

  * fuel — amount of fuel consumed during the period

  * start_odo — odometer reading at the beginning of the period

  * stop_odo — odometer reading at the end of the period

### Fuel consumption and idle statistics — GET `fuelconsumtion`
This API provides data on how much fuel was consumed during the selected time period, as well as how long the vehicle was idling.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=fuelconsumtion — API command to get the report

  * imei — unique vehicle identifier

  * start — start time of the data range (Unix timestamp)

  * stop — end time of the data range (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=fuelconsumtion&imei=7157153151020&start=1644741475&stop=1644914275&node=1  
---|---  
  
Response

| { "code": 0, "data": { "7157153151020": [ { "idle": 98872, "fuel consumed": 457.92 } ] }, "message": "success" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success, other values = error)

  * data — object data for the selected vehicle:

  * idle — engine idling time (in seconds)

  * fuel consumed — amount of fuel consumed during the selected period (liters)

  * message — response status message

### Vehicle status and distance to point or geofence — GET `get_status_and_distance`
This API provides the current status of a vehicle and the time and distance to a specified point or geofence.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=get_status_and_distance — command to get the vehicle status and distance

  * vehnum — garage number or license plate of the vehicle; multiple values can be specified separated by commas

  * zone — geofence name (if you want to calculate distance to a geofence)

  * point — coordinates of a point in the format latitude,longitude (if you want distance to a specific point)

  * node — node number where the command should be executed




### Example requests

| https://<server_address>/api/api.php?cmd=get_status_and_distance&vehnum=M897ET777&zone=Hospital%20Lapino&node=1  
---|---  
  
| https://<server_address>/api/api.php?cmd=get_status_and_distance&vehnum=M897ET777&point=55.923032,37.659668&node=1  
---|---  
  
### Response

| { "cstatus": 6, "cstatus_timestamp": 1554985159, "destination_name": "Zero coordinates", "distance": { "code": 0, "length": 27613, "msg": "OK", "point": "55.923032,37.659668", "time": 2002, "type": "point" }, "ignition": 1, "rbu": "08", "sensors": { "Unloading Sensor": "on|1554985138", "Loading Sensor": "on|1554985138", "Ignition Sensor": "on|1554985138", "FUEL SENSORS OPERATION SENSORS": "Operating|1554985138", "Fuel ... fuel": "202.96 Liter|1554995669" }, "source_name": "Loading_Chertanovo", "status": 4, "status_timestamp": 1554985072, "unixtimestamp": 1554995864, "vehiclenumber": "M897ET777", "zone": [] }  
---|---  
  
In response to the API request, the following is returned:

  * cstatus — current status of the vehicle

  * cstatus_timestamp — timestamp of the current status (Unix timestamp)

  * destination_name — name of the destination point

  * distance — object containing information about distance and time to a point or geofence:

  * length — distance in meters

  * time — time in seconds

  * type — type of object (point or zone)

  * point — coordinates of the point (if type=point)

  * ignition — ignition state (1 = on)

  * rbu — RBU identifier

  * sensors — status of various sensors (e.g., loading/unloading, fuel)

  * source_name — name of the data source

  * status — current status of the vehicle

  * status_timestamp — timestamp of the last status change

  * unixtimestamp — timestamp when the data was retrieved

  * vehiclenumber — vehicle license plate or garage number

  * zone — array of current geofences (if any)

### Vehicle idle time — GET `get_idle`
This API allows you to get information about vehicle idle periods.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET

### Request parameters

Parameters can be sent via the query string or in the POST request body:

  * cmd=get_idle — command to retrieve idle periods

  * node — the number of the node where the command should be executed

  * time_start — start of the period (timestamp, unixtime)

  * time_end — end of the period (timestamp, unixtime)

  * imei — IMEI of the monitoring device. If there are multiple devices, separate them with commas: imei=887556,io9987,76573




### Example API request

| https://<server_address>/api/api.php?cmd=get_idle&time_start=16878956&time_end=16878755&imei=887556,io9987,76573&node=1  
---|---  
  
### Example response

| { "code": 0, "data": { "2914": [ {"idle_start": "1641814740", "idle_end": 1641814984}, {"idle_start": 1641815547, "idle_end": 1641825619}, {"idle_start": 1641827105, "idle_end": 1641893307}, {"idle_start": 1641893623, "idle_end": 1641898037} // ... other entries ... ] }, "message": "success" }  
---|---  
  
The API response contains:

  * code — result code: 0 — success, 1 — error

  * data — a dictionary where keys are vehicle identifiers and values are lists of idle periods:

  * idle_start — start time of the idle period (timestamp)

  * idle_end — end time of the idle period (timestamp)

  * message — text message with the result of the request

### Tracking link for object — GET `get_temp_link`
This API is used for getting a temporary link to track an object on the map, with activation and deactivation based on specified geofences.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=get_temp_link — command to get a temporary link

  * imei — unique identifier of the object (vehicle) in the system

  * startgeo — geofence for link activation

  * stopgeo — geofence for link deactivation

  * max_duration — maximum duration of the link in minutes (default: 1440 minutes / 24 hours)




### Example request

| https://<server_address>/api/api.php?cmd=get_temp_link&imei=356307045913463&startgeo=Rostov test API&stopgeo=Rostov exit test API&max_duration=800  
---|---  
  
Response

| https://<server_address>/monitor_token.php?token=1f87a19c068ad47f3f769dc151527794&lang=en&zoom=10&startgeo=Rostov test API&stopgeo=Rostov exit test API  
---|---  
  
The API returns a direct link to the map with a temporary token. The link respects the specified geofences for activation (startgeo) and deactivation (stopgeo).

### Send command to vehicle — GET `send_command`
This API sends a command to a vehicle using a pre-created command template in the [Commands ](<commands_.html>)module.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=send_command — API command to send a command to a vehicle

  * agent_id — vehicle (agent) identifier

  * template_name — name of the pre-created command template

  * node — node number where the command should be executed (optional)




### Example request

| https://<server_address>/api/api.php?cmd=send_command&agent_id=139849&template_name=test123&node=1  
---|---  
  
Response 

| { "code": 0, "msg": null, "command_id": 3989 }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message about the result of the operation

  * command_id — identifier of the sent command

### Sent command status — GET `get_command_status`
This API retrieves the status of a complex command, including the overall status and the status/responses from all objects and sub-commands included in the complex command.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=get_command_status — API command to request the status of a command

  * command_id — identifier of the complex command

  * node — node number where the command should be executed 




### Example request

| https://<server_address>/api/api.php?cmd=get_command_status&command_id=3989&node=1  
---|---  
  
Response 

| { "code": 0, "message": "", "detailed_status": { "43207": [ { "type": "GPRS", "status": "accepted", "response": "Ver: 03.25.15_88 GPS: AXN_3.80_3333 Hw: FMB010 Mod: 3 IMEI: 352094083043221 Init: 2024-3-30 12:29 Uptime: 505289 MAC: 001E428490AF SPC: 0 (0) AXL: 0 OBD :0 BL:0,2 BT:3" }, { "type": "GPRS", "status": "accepted", "response": "Data channel: 1 GPRS: 1 Phone: 0 SIM: 0 OP: 25001 Signal: 4 New SMS: 0 Roaming: 0 SMSFull: 0 LAC: 10 Cell ID: 11522 NetType: 1 FwUpd: -65536" } ] }, "general_status": "completed", "version": "7.2.0" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * message — server message about the result

  * detailed_status — associative array with detailed information for each agent:

  * key (e.g., 43207) — agent identifier

  * type — type of communication channel

  * status — command execution status (accepted, executed, etc.)

  * response — text response from the device

  * general_status — overall status of the complex command (pending, completed, failed)

  * version — system version

### Fuel card transactionss — GET `fuel`
Use this API to retrieve data about vehicle refueling over a selected period. With it, you can:

— view fuel card transactions (fuel purchases, card balance, fuel type, gas station)

— get data on fuel refills and drains from the vehicle’s sensor (coordinates, fuel amount, event location)

— monitor fuel levels at the start and end of each day for every vehicle

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=fuel — command to get fuel data

  * imei — vehicle identifier in the system

  * start — start time of the period (Unix timestamp)

  * stop — end time of the period (Unix timestamp)

  * addr — адрес заправок

  * node — node number on which to execute the command




### Example request

| https://<server_address>/api/api.php?cmd=fuel&imei=863591021267806&start=1404158400&stop=1406836800&addr =1&node=1  
---|---  
  
The JSON response contains three main sections:

1\. Fuel Cards (cards)

Array of cards with information about each card and its transactions:

| "cards": [ { "id": 601,  "card_num": "257464691",  "balance": "0", "type_name": "Magistral", "transactions": { "1404206488": { "operation": "Purchase",  "ts": 1404206488,  "azs": "Gas Station Name",  "liters": "20.0000",  "sum": "636.00",  "sumg": "658.26", "fuel": "Diesel",  "price": "31.80", "priceg": "32.91",  "saldo": "0.00" } } } ]  
---|---  
  
  * id — card ID in PILOT system

  * card_num — card number

  * balance — card balance at the time of the query

  * type_name — card type

  * transactions — fuel card transactions:

  * operation — type of operation (Purchase/Return, etc.)

  * ts — transaction timestamp

  * azs — gas station name

  * liters — fuel volume

  * sum — discounted amount

  * sumg — full amount

  * fuel — fuel type

  * price — discounted price per liter

  * priceg — full price per liter

  * saldo — card balance at the transaction

2\. Sensor Fillings/Drains (fillings)

Object where keys are event timestamps and values contain data about fuel refills or drains:




| "fillings": { "1404205495": { "ts": 1404205495, "type_id": 1,  // 1 = refill, 2 = drain "liters": "23.2862", "lat": "51.9899", "lon": "47.8203", "address": "RU, Saratov Region, Balakovo", "fuel_start": "223.68" // fuel level at start of event } }  
---|---  
  
  * ts — event time (Unix timestamp)

  * type_id — event type (1 = refill, 2 = drain)

  * liters — fuel amount

  * lat/ lon — coordinates

  * address — location description

  * fuel_start — fuel level at the start of the event

3\. Daily Fuel Balances (fuel)

Object where keys are day start timestamps and values contain fuel balances:




| "fuel": { "1404072000": { "ts": 1404072000,  // day start timestamp "te": 1404158400,  // day end timestamp "start": "4.76", // fuel at start of day (liters) "stop": "18.93" // fuel at end of day (liters) } }  
---|---  
  
  * ts — day start timestamp

  * te — day end timestamp

  * start — fuel at the start of the day

  * stop — fuel at the end of the day

### Add fuel card transaction — POST `add_fuel_transaction`
This API adds a fuel transaction record for a fuel card, including information about the amount of fuel, cost, location, and driver.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

Required:

  * cmd=add_fuel_transaction — API command to add a transaction

  * card_num — fuel card number

  * operation — type of operation (e.g., refill)

  * unixtimestamp — transaction time in Unix timestamp format

  * place — location of the operation

  * azs — name of the fuel station

  * liters — amount of fuel in liters

  * fuel — fuel type

  * price — price per liter without discount

  * sum — total amount without discount

  * node — node number where the command should be executed




Optional:

  * priceg — price per liter with discount

  * sumg — total amount with discount

  * driver — driver’s full name

  * lat — latitude of the transaction location

  * lon — longitude of the transaction location

  * info — additional information

  * internal_id — internal transaction identifier




### Example request 

| https://<server_address>/api/api.php?cmd=add_fuel_transaction&node=1  
---|---  
  
Example request body (JSON):

| { "card_num": "1234567890123456", "operation": "refill", "unixtimestamp": 1695000000, "place": "Main street 12", "azs": "WOG", "liters": 50, "fuel": "Diesel", "price": 55.0, "sum": 2750.0, "driver": "Ivan Ivanov" }  
---|---  
  
Response

| { "code": 0, "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message about the operation result

### Fuel station list — GET `azs`
This API gets a list of fuel stations (gas stations) including coordinates, type, and description.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=azs — API command to get the list of fuel stations

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=azs&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "list": [ { "lat": "50.5", "lon": "30.3643", "type_id": 8, "type_name": "RosBerlio", "descr": "<b>WOG Gas Station</b><br>Phone: (+38033)2787914<br>Address: Okr. Road, Berkovetskaya St, 6, between Varshavska and Zhytomyr Tr., near Auchan and Epicenter" }, { "lat": "50.6586", "lon": "29.8808", "type_id": 8, "type_name": "RosBerlio", "descr": "<b>AviaCom Gas Station</b><br>Phone: (+38045)7752175<br>Address: 56 km of M-07 (E-373) Kyiv-Kovel-Yagodyn-Lublin" }, { "lat": "55.551", "lon": "53.4085", "type_id": 8, "type_name": "RosBerlio", "descr": "<b>Proton-A LLC Gas Station</b><br>Phone: 8-919-680-07-77<br>Address: 1130 km of M7 highway, Tatarstan, Aktanyshsky District (left side)" } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message (e.g., "OK")

  * list — array of fuel station objects, each containing:

  * lat — latitude of the station

  * lon — longitude of the station

  * type_id — fuel station type ID

  * type_name — fuel station type name

  * descr — station description including address and contact phone

### Trip report — GET `run`
This API is used for getting information about a vehicle’s trips over a specified period. When the **Geofences** module is enabled, each trip can be split into segments based on entry and exit from geofences.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=run — command to get the trip report

  * imei — unique identifier of the object (vehicle)

  * start — start time of the period (Unix timestamp)

  * stop — end time of the period (Unix timestamp)

  * zones — include geozone information:

— 0 — tracks are returned as whole trips, without splitting by zones

— 1— trips are split into segments based on entry/exit from geozones

  * eco— include eco-driving data in tracks

  * node — node number on which to execute the command




### Example requests

| https://<server_address>/api/api.php?cmd=run&imei=359772039289781&start=1406318400&stop=1406404800&zones=1&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "zones": { "1406341994": { "ts": 1406341994, "stopuid": "213854753412306", "stopname": "Garage", "lat": "53.3861", "lon": "83.7127", "msgtype": 2 }, "1406353422": { "ts": 1406353422, "stopuid": "966971618589014", "stopname": "Barnaul Bus Station", "lat": "53.3508", "lon": "83.7593", "msgtype": 1 } }, "tracks": { "1406341955": { "ts": 1406341955, "te": 1406341994, "length": 0.26, "maxspeed": "17", "avgspeed": 17 }, "1406341994": { "ts": 1406341994, "te": 1406353389, "length": 119.83, "maxspeed": "96", "avgspeed": 58 } } }  
---|---  
  
In response to the API request, the following is returned:

Zones array (zones) — geofence entry and exit points:

  * ts — event time (Unix timestamp)

  * stopuid — unique geofence identifier

  * stopname — geofence name

  * lat — latitude of the point

  * lon — longitude of the point

  * msgtype — event type (1 = entry, 2 = exit)




Tracks array (tracks) — trip information:

  * ts — trip start time (Unix timestamp)

  * te— trip end time (Unix timestamp)

  * length — trip distance in kilometers

  * maxspeed— maximum speed during the trip (km/h)

  * avgspeed — average speed during the trip (km/h)

  * lats — latitude of trip start

  * lons — longitude of trip start

  * late — latitude of trip end

  * lone — longitude of trip end

  * eco — eco-driving data (if eco parameter is enabled):

  * Acceleration, Braking, Speed — metrics for each parameter

### Parking and stops report — GET `runstops`
This API is used for getting information about vehicle stops and parking events over a specified period. You can get coordinates, duration, and the address of the stop or parking location.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=runstops — API command for getting stop and parking report

  * imei— vehicle identifier in the system

  * start— start of the period (Unix timestamp)

  * stop— end of the period (Unix timestamp)

  * node— node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=runstops&start=1676840400&stop=1676926800&imei=16518&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "stops": [ { "ts": 1676840400, "te": 1676873376, "dur": 32976, "lat": "56.733388", "lon": "61.051853", "address": { "road": "R-351", "county": "Beloyarsky Urban District", "state": "Sverdlovsk Oblast", "region": "Ural Federal District", "postcode": "624053", "country": "Russia", "country_code": "ru" } }, { "ts": 1676875342, "te": 1676880065, "dur": 4723, "lat": "56.893278", "lon": "60.770452", "address": { "road": "Yekaterinburg Ring Road", "county": "Beryozovsky Urban District", "state": "Sverdlovsk Oblast", "region": "Ural Federal District", "postcode": "623703", "country": "Russia", "country_code": "ru" } } ], "parkings": [ { "ts": 1676887881, "te": 1676889637, "dur": 1756, "lat": "56.781017", "lon": "58.40189", "address": { "road": "Access to Zobnina from km 216+740 of Perm – Yekaterinburg highway", "county": "Achitsky District", "state": "Sverdlovsk Oblast", "region": "Ural Federal District", "postcode": "623235", "country": "Russia", "country_code": "ru" } } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message (e.g., "OK")

  * stops — array of stop data:

  * ts— stop start time (Unix timestamp)

  * te— stop end time (Unix timestamp)

  * dur— duration of the stop in seconds

  * lat— latitude of the stop

  * lon— longitude of the stop

  * address— address details of the stop (street, district/county, state, region, postal code, country, country code)

  * parkings— array of parking data, structured similarly to stops

### Trip report with geolocation — GET `rungeo`
This API provides a detailed report on a vehicle’s movements during a selected period, including coordinates and geographic information (address, district, city, etc.).

The data includes start and end points of each trip, average and maximum speed, trip length, and location details based on geo-coordinates.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=rungeo — command to retrieve the trip report

  * imei — unique identifier of the vehicle in the system

  * start — start time of the report period (Unix timestamp)

  * stop — end time of the report period (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=rungeo&imei=356307045913463&start=1439413200&stop=1439586000&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "tracks": { "1439443509": { "avgspeed": 35.3889, "length": 12.7304, "maxspeed": 59, "ts": 1439443509, "te": 1439445837, "slat": "47.2037", "slon": "39.6325", "elat": "47.2037", "elon": "39.6325", "sgeo": { "city": "Rostov-on-Don", "road": "2-ya Krasnodarskaya ulitsa", "house_number": "80 к13", "state": "Rostov Oblast", "postcode": "344091" }, "egeo": { "city": "Rostov-on-Don", "road": "2-ya Krasnodarskaya Street", "house_number": "80 к13", "state": "Rostov Oblast", "postcode": "344091" } } } }  
---|---  
  
In response to the API request, the following is returned:

  * code — execution status (0 = success)

  * msg — status message

  * tracks — object, where keys are trip start timestamps (Unix) and values contain trip data




For each trip:

  * avgspeed — average speed (km/h)

  * maxspeed — maximum speed (km/h)

  * length — route length (km)

  * ts — trip start time (Unix timestamp)

  * te — trip end time (Unix timestamp)

  * slat, slon — start coordinates (latitude, longitude)

  * elat, elon — end coordinates (latitude, longitude)

  * sgeo — start location address (city, street, house, postal code)

  * egeo — end location address (city, street, house, postal code)

### Track data — GET `gettrack`
This API loads detailed route points (track data) for a trip previously obtained via the rungeo method. Each track point contains coordinates, speed, and a timestamp relative to the start of the trip.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=gettrack — command to retrieve the track

  * id — track ID obtained from the rungeo API response

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=gettrack&id=70685695&node=1  
---|---  
  
Response

| { "track_data": "47.2037;39.6325;10;0:47.2037;39.6324;13;1:47.2037;39.6323;15;3:...", "track_id": 70685695, "unixstarttimestamp": 1439443509 }  
---|---  
  
In response to the API request, the following is returned:

  * track_id — unique identifier of the track

  * unixstarttimestamp — start date and time of the track (Unix timestamp)

  * track_data — sequence of track points separated by a colon :




Each track point consists of 4 parameters separated by a semicolon ;:

1\. Latitude (lat)

2\. Longitude (lon)

3\. Speed (km/h)

4\. Seconds since the start of the track (sec)

### Approved track management — GET `get_approved_tracks`, `set_approved_tracks`
This API helps work with approved vehicle tracks: set periods, retrieve tracks, and use the track player.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

Parameters are passed through the query string using either POST or GET, depending on the command.

To get the required data, add parameters to the request URL. Parameters are added after the question mark ? and separated by &.

  * cmd=set_approved_tracks — command to set approved periods

  * cmd=get_approved_tracks — command to get approved tracks

  * node — the number of the node where the command should be executed

  * veh — vehicle registration number or identifier

  * ts — start of the period (timestamp)

  * te — end of the period (timestamp)




### Set approved periods

Example API request:

| https://<server_address>/api/api.php?cmd=set_approved_tracks&veh=Р852ОВ77&ts=1537945200&te=1537952400&node=1  
---|---  
  
API response:

| {"code":0,"msg":"OK updated"}  
---|---  
  
### Get approved tracks

Example API request:

| http://<server_address>/api/api.php?cmd=get_approved_tracks&veh=Р852ОВ77&ts=1537945200&te=153795 2400  
---|---  
  
API response:

| { "code":0, "data":{ "approved":[ {"length":2.8051348330013,"ts":1537948809,"te":1537949431,"max_speed":"59","avg_speed":26} ], "not_approved":[ {"length":1.8650025635569,"ts":1537945206,"te":1537946030,"max_speed":"40","avg_speed":12}, {"length":4.1987356239849,"ts":1537948298,"te":1537948798,"max_speed":"65","avg_speed":37} ] } }  
---|---  
  
In the API response:

  * approved — list of approved tracks

  * not_approved — list of tracks that were not approved

  * length — track length in kilometers

  * ts — track start time (timestamp)

  * te — track end time (timestamp)

  * max_speed — maximum speed on the track

  * avg_speed — average speed




### Track player

The track player is a web service that allows visual viewing of vehicle tracks. Unlike the regular API, it immediately returns a ready-made page with the map and track, not JSON or XML.

Link to view the track:

| http://<server_address>/api/track_player.php?login=demo&pass=demo&ts=1536933600&te=1536940800&veh=в848ае199&lang=ru  
---|---  
  
You can use this URL as the iframe src to display the track on a webpage.

### Get report — GET `get_report`
This API generates a report for vehicles, drivers, zones, clients, or tags over a selected time period, with detailed options for customizing the report content.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

Required:

  * cmd=get_report — API command to retrieve a report

  * report_type — report type (numeric identifier)

  * start — start of the period (Unix timestamp)

  * stop — end of the period (Unix timestamp)

  * veh_id — vehicle IDs (comma-separated)

  * explode — data separation: 1 — by days, 2 — by weeks, 3 — no separation

  * group — data grouping: 1 — by days, 2 — by objects, 3 — by zones, 4 — by drivers, 5 — by clients, 6 — by groups, 7 — by tags

  * format— report format: json, pdf, xls

  * tz — time zone of the report (e.g., Africa/Johannesburg)




Optional:

  * drivers_id — list of driver IDs

  * zones_id — list of geofence IDs

  * fillings — include refueling data

  * stales — include idle periods

  * speed — include speed data

  * rashod — include fuel consumption

  * stops — include stops

  * run — include engine run data

  * contr_time/ type — control time

  * tags — list of tag IDs

  * template — report template ID

  * outside_zones — include external zones

  * work_hours — include only working hours

  * fuel — include fuel data

  * vehicle_not_moving_time — include idle time for the report

  * vehicles_has_covered_km — include vehicle mileage

  * notifications — list of notification IDs




### Example GET request

| https://<server_address>/api/api.php?cmd=get_report&report_type=1&start=1724623200&stop=1724709600&veh_id=1234,5678&explode=1&group=2&format=json &tz=Africa/Johannesburg&node=1  
---|---  
  
### Example POST request

| { "cmd": "get_report", "report_type": 1, "start": 1724623200, "stop": 1724709600, "veh_id": "1234,5678", "explode": 1, "group": 2, "format": "json", "tz": "Africa/Johannesburg" }  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": [ { "veh_id": "1234", "date": "2025-09-22", "distance": 125.5, "fuel_consumption": 15.2, "stops": 5, "speed_avg": 60 }, { "veh_id": "5678", "date": "2025-09-22", "distance": 98.3, "fuel_consumption": 12.7, "stops": 4, "speed_avg": 55 } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = successful operation)

  * msg — server message

  * data — array of report data

  * veh_id — vehicle ID

  * date — report date

  * distance — distance traveled (km)

  * fuel_consumption — fuel consumed

  * stops — number of stops

  * speed_avg — average speed

### Report list — GET `reports_list`
This API retrieves a list of all available reports in the account, including their IDs, names, and the groups they belong to.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

  * cmd=reports_list — command to get the list of reports

  * node — node number where the command should be executed 




### Example GET request

| https://<server_address>/api/api.php?cmd=reports_list&node=1  
---|---  
  
Response

| { "code": 0, "data": [ { "id": 266, "name": "Administrative Actions", "group": "Administrator" }, { "id": 258, "name": "Blocked Users", "group": "Administrator" }, { "id": 263, "name": "Created Users", "group": "Administrator" }, { "id": 261, "name": "Disabled User Account", "group": "Administrator" }, { "id": 265, "name": "Inactive Users", "group": "Administrator" }, { "id": 267, "name": "Failed Login Attempts", "group": "Administrator" } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 means the operation was successful)

  * data — array of available reports:

  * id — report ID

  * name — report name

  * group — group the report belongs to

### Add geofence — GET `geofenceadd`
This API creates a new geofence, specifying its name, type, color, group, and geometry.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=geofenceadd — command to add a geofence

  * zonename — geofence name

  * zonetype — type of the geofence (1 — polygon, 2 — circle)

  * color — geofence color in HEX format (e.g., #FFFFFF)

  * info — text information about the geofence

  * group_name — name of the geofence group (created if it doesn’t exist, optional)

  * group_id — ID of an existing group (if specified, group_name is ignored, optional)

  * geometry — GEOJson describing the polygon or circle

  * external_id — external identifier for the geofence (optional)

  * node — node number where the command should be executed




### Example requests

Polygon:

| http://<server_address>/api/api.php?cmd=geofenceadd&zonetype=1&zonename=test_api_polygon&external_id=12354&info=blabla&color=%23FF3300&group_name=TEST_API&geometry={"type":"Polygon","coordinates":[[[55.184334,25.112866],[55.183512,25.113472],[55.182154,25.112516],[55.183511,25.111016],[55.184923,25.112133]]]}&node=1  
---|---  
  
Circle:

| http://<server_address>/api/api.php?cmd=geofenceadd&zonetype=2&zonename=test_api_circle&external_id=12345&info=circle_info&color=%23FF3300&group_name=TEST_API&geometry={"type":"Circle","coordinates":[55.184334,25.112866],"radius":150}&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": { "id": 158412, "zonename": "test_api_polygon", "zonetype": 1, "external_id": "12354", "created_at": 1610536445, "updated_at": 1610536445, "color": "#FF3300", "info": "blabla", "group_id": 6984 } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message

  * data — object with information about the created geofence:

  * id — geofence identifier

  * zonename — geofence name

  * zonetype — geofence type (1 — polygon, 2 — circle)

  * external_id — external identifier

  * created_at — creation time (Unix timestamp)

  * updated_at — last update time (Unix timestamp)

  * color — geofence color

  * info — text information

  * group_id — geofence group identifier

### Geofence list — POST `geofencelist`
This API returns a list of all geofences with their characteristics, including coordinates, type, color, and group.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=geofencelist — API command to get the list of geofences

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=geofencelist&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": [ { "id": 157828, "zonename": "Test Magnit", "zonetype": 2, "external_id": null, "created_at": 1609780839, "updated_at": 1609780839, "color": "#00CC00", "info": "geozone text info", "group_name": "TEST", "group_id": 6531, "geometry": { "type": "Circle", "coordinates": [40.036497, 46.981936], "radius": 305 } }, { "id": 153244, "zonename": "school", "zonetype": 1, "external_id": 1234, "created_at": 1609780839, "updated_at": 1609780839, "color": "#FF9900", "info": "kml upload", "group_name": "TEST", "group_id": 6531, "geometry": { "type": "Polygon", "coordinates": [ [ [55.184334, 25.112866], [55.183512, 25.113472], [55.182154, 25.112516], [55.183511, 25.111016], [55.184923, 25.112133] ] ] } } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message

  * data — array of geofence objects, each containing:

  * id — geofence identifier

  * zonename — geofence name

  * zonetype — geofence type (1 — polygon, 2 — circle)

  * external_id — external identifier (if any)

  * created_at — creation time (Unix timestamp)

  * updated_at — last update time (Unix timestamp)

  * color — color of the geofence in the interface

  * info — additional information

  * group_name — name of the geofence group

  * group_id — group identifier

  * geometry — geofence geometry:

  * type — type (Circle or Polygon)

  * coordinates — coordinates (for circle: [longitude, latitude]; for polygon: array of arrays of coordinates)

  * radius — radius for circle geofence in meters

### Link geofence to object — GET `geofencelink`
This API links an existing geofence to a vehicle, allowing you to set control parameters such as speed limits, idle time, and alerts.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=geofencelink — command to link a geofence

  * zone_id — geofence ID (required if external_id is not specified)

  * external_id — external identifier of the geofence (optional, ignored if zone_id is provided)

  * agent_id — identifier of the agent (vehicle)

  * idle — idle time control in the geofence in minutes (optional)

  * speedlimit — speed limit in the geofence in km/h (optional)

  * alerts — alerts configuration:

  * 0 — no alerts

  * 1 — idle alert

  * 2 — border crossing alert

  * 3 — border and checkpoint alert

  * node — node number where the command should be executed




### Example request

| http://<server_address>/api/api.php?cmd=geofencelink&zone_id=158414&agent_id=66497&idle=10&speedlimit=80&alerts=0&node=1  
---|---  
  
Response 

| { "code": 0, "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message indicating the result of the operation

### Unlink geofence from object — GET `geofenceunlink`
This API removes the link between an existing geofence and a vehicle.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=geofenceunlink — command to unlink a geofence

  * zone_id — geofence ID (required if external_id is not specified)

  * external_id — external identifier of the geofence (optional, ignored if zone_id is provided)

  * agent_id — identifier of the agent (vehicle)

  * node — node number where the command should be executed




### Example request

| http://<server_address>/api/api.php?cmd=geofenceunlink&zone_id=158414&agent_id=66497&node=1  
---|---  
  
Response 

| { "code": 0, "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message indicating the result of the operation

### Geofence visit history — GET `ag_geozones`
This API retrieves information about when objects (vehicles) entered and exited specific geozones over a specified period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=ag_geozones — API command to get geozone visit history

  * start — start of the period (Unix timestamp)

  * stop — end of the period (Unix timestamp)

  * imei — vehicle identifier(s). Multiple IMEIs can be provided, separated by commas

  * node — node number where the command is executed




### Example request for a single vehicle

| https://<server_address>/api/api.php?cmd=ag_geozones&start=1606770000&stop=1608584399&imei=865291046424635&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": [ { "group": "General", "zonename": "Golitsyno Base", "ts": 1606805707, "te": 1606808500 }, { "group": "General", "zonename": "Golitsyno Base", "ts": 1606865643, "te": 1606868103 } ] }  
---|---  
  
### Example request for multiple vehicles

| https://<server_address>/api/api.php?cmd=ag_geozones&start=1606770000&stop=1608584399&imei=865291046424635,867481037184458  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": { "865291046424635": [ { "group": "General", "zonename": "Golitsyno Base", "ts": 1606805707, "te": 1606808500 }, { "group": "General", "zonename": "Golitsyno Base", "ts": 1606865643, "te": 1606868103 } ], "867481037184458": [ { "group": "General", "zonename": "Golitsyno Base", "ts": 1607949101, "te": 1607956478 }, { "group": "General", "zonename": "Golitsyno Base", "ts": 1608012176, "te": 1608041334 } ] } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message (e.g., "OK")

  * data — geozone visit information:

  * If single object, data is an array of visits

  * If multiple objects, data is an object where keys are vehicle IMEIs, and values are arrays of visits

  * group — geozone group

  * zonename — name of the geozone

  * ts — entry time into the geozone (Unix timestamp)

  * te — exit time from the geozone (Unix timestamp)

### Mileage inside geofences — GET `zones_mileage`
This API gets information about the mileage of vehicles within specified geofences for a selected period of time.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=zones_mileage — command for getting mileage in geofences

  * ts — start time of the period (Unix timestamp)

  * te — end time of the period (Unix timestamp)

  * imei — list of device IMEIs, separated by commas

  * zones — list of geofence names, separated by commas (optional; if not specified, mileage for all zones is returned)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=zones_mileage& ts=1596229200&te=1597006800&imei=867857035056105,123123123&zones=Simferopol,Belogorsk,Sudak&node=1  
---|---  
  
Response

| { "code":0, "ts":"1596229200", "te":"1597006800", "data":{ "867857035056105":[ { "zone":"Simferopol", "duration":88308, "mileage":259.84 }, { "zone":"Outside city", "duration":21564, "mileage":283.47 }, { "zone":"Belogorsk", "duration":704, "mileage":10.77 }, { "zone":"Sudak", "duration":1332, "mileage":11.45 } ] } }  
---|---  
  
In response to the API request, the following is returned:

  * zone — geofence name

  * duration — time spent in the zone in seconds

  * mileage — distance traveled in the zone in kilometers

### Delete geofence — GET `geofencedel`
This API deletes a geofence from the system. When a geofence is deleted, all links between this geofence and vehicles are automatically removed.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=geofencedel — command to delete a geofence

  * zone_id — internal geofence identifier

  * external_id — external geofence identifier (optional)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=geofencedel&zone_id=473989&node=1  
---|---  
  
Response 

| { "code": 0, "msg": "OK", "data": { "zones_deleted": [ 473989 ] } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * message — server message indicating the result of the operation

  * data.zones_deleted — an array of IDs of deleted geofences (zone_id) for which the operation was completed successfully

### Create driver — GET `drivers_add`
This API allows you to add a new driver to the system or update an existing driver’s information. You can specify the full name, iButton code, contact information, driver’s license number, and a list of objects the driver has access to.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=drivers_add — command to add or update a driver

  * name — driver’s full name

  * code — driver’s iButton code (required)

  * description — driver description (optional)

  * phone — driver’s phone number (optional)

  * license — driver’s license number (optional)

  * email — driver’s email address

  * access — comma-separated list of object IDs (agent_id) the driver is allowed to access

  * node — node number where the command should be executed




| If a driver with the specified parameters already exists, the API will update their data. If not, a new driver will be created.  
---|---  
  
### Example request

| https://<server_address>/api/api.php?cmd=drivers_add&name=NewDriverName&code=123456&description=DESCR&phone=122212343&license=rrr3335552&email=new@email.com&access=1122,3344&node=1  
---|---  
  
Response

| { "code": 0, "data": { "id": 16990, "name": "NewDriverName", "code": "123456", "description": "DESCR", "phone": "122212343", "license": "rrr3335552", "email": "new@email.com", "access": [1122, 3344] } }  
---|---  
  
In response to the API request, the following is returned:

  * id — unique driver ID

  * name — full name of the driver

  * code — iButton code of the driver

  * description — driver description

  * phone — phone number

  * license — driver’s license number

  * email — email address

  * access — list of object IDs the driver has access to

### Drivers list — GET `drivers_list`
This API is used to get information about drivers registered in the account. It allows retrieving data for each driver, including full name, contact information, description, access rights, and identifiers.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=drivers_list — command to get the list of drivers

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=drivers_list&node=1  
---|---  
  
Response

| { "code": 0, "data": [ { "id": 317, "name": "Ivan Ivanov", "code": "", "description": "Driver #3", "phone": "798345546", "license": "", "email": "", "access": [] }, { "id": 1122, "name": "Andrey Petrov", "code": "", "description": "Driver #1", "phone": "+525531696255", "license": "", "email": null, "access": [1122] } ] }  
---|---  
  
In response to the API request, the following is returned:

  * id — driver identifier

  * name — full name of the driver

  * code — driver code (if available)

  * description — driver description

  * phone — phone number

  * license — driver’s license data

  * email — email address

  * access — list of resource or object IDs the driver has access to

### Assign driver to vehicle — GET `linkdriver`
This API links a driver to a specific vehicle using its unique identifier (IMEI) and the driver’s key.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=linkdriver — API command for driver linking

  * imei — unique vehicle identifier in the system

  * driver — driver’s full name

  * driverkey — driver’s key number

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=linkdriver&imei=548545218454&driver=ADAS+driver&driverkey=89185717259&node=1  
---|---  
  
Response

| { "code": 0, "data": [], "message": "success" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success, other values = error)

  * data — additional data (empty array in this case)

  * message — server response message (e.g., "success")

### Driver activity report — GET `gettachodata`
This API retrieves information about driver activities for vehicles over a selected period. The response includes different work modes (e.g., driving, working, resting).

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=gettachodata — command to retrieve tachograph data

  * agent_id — vehicle ID (or multiple IDs, separated by commas)

  * imei — device ID (alternative to agent_id)

  * ts — start time (Unix timestamp)

  * te — end time (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=gettachodata&ts=1624568400&te=1624586400&agent_id=120407,120646&node=1  
---|---  
  
Response

| { "С 220 СК 750": { "First driver": { "Work": 4997, "Drive": 248, "Rest": 9117 }, "Second driver": { "Driver available": 1722, "Rest": 9117 } }, "А 152 АК 790": { "First driver": { "Drive": 5436, "Work": 1706, "Rest": 9084 }, "Second driver": { "Driver available": 4995, "Rest": 9084 } } }  
---|---  
  
In response to the API request, the following is returned:

  * vehicle number — license plate of the vehicle

  * First driver / Second driver — data for each driver

  * Drive — driving time (in seconds)

  * Work — working time (in seconds)

  * Rest — resting time (in seconds)

  * Driver available — time when the driver was available for work (in seconds)

### Notifications configuration — GET 
This API is used to create, retrieve, update, and delete notification configurations in the PILOT system.

This API is not intended for sending notifications. Instead, it defines the conditions under which notifications will be triggered in the future.

### Supported HTTP methods

POST — create a new notification configuration

GET — retrieve a notification configuration by ID

PUT — update an existing notification configuration

DELETE— remove one or more notification configurations

### Request address

To get the data, use the address: https://<server_address>/api/ptm/notification.php

## POST 

Creates a new notification configuration.

The request body is required.

Request URL

| https://<server_address>/api/ptm/notification.php  
---|---  
  
### Request body example (JSON)

| { "id": 0, "agent_id": 123, "type": "speed", "geozones": [ { "name": "Warehouse", "zonetype": 1, "points": [ [55.7558, 37.6173], [55.7560, 37.6180], [55.7565, 37.6170] ] } ], "name": "Speeding in warehouse zone", "email": true, "emails_list": [ "dispatcher@example.com", "manager@example.com" ], "sms": true, "phones_list": [ "+79001234567", "+79007654321" ], "message_text": "Alert! Speed limit exceeded in warehouse zone.", "webhook": true, "webhook_url": "https://yourdomain.com/webhook-handler", "ts": 1680000000, "te": 1710000000, "timezone": 3, "zone_rule": "in", "speed_rule": ">", "speed_value": 80, "speed_time": 15, "speed_time_units": "ss", "ignition_rule": "on", "geozones_rule": "in", "break_duration": 0, "break_time_units": "ss", "tag_name": "truck", "temperature_rule": ">", "temperature_value": 30, "temperature_time": 0, "disconnect_time": 0, "disconnect_time_units": "ss", "odometer_rule": ">", "odometer_value": 100000, "odometer_period": "abs" }  
---|---  
  
### Response example

| { "success": true, "msg": "Notification successfully created", "method": "POST", "notification": { "id": 123, "agent_id": 123, "type": "speed", "geozones": [ { "name": "Warehouse", "zonetype": 1, "points": [ [55.7558, 37.6173], [55.7560, 37.6180], [55.7565, 37.6170] ] } ], "name": "Speeding in warehouse zone", "email": true, "emails_list": [ "dispatcher@example.com", "manager@example.com" ], "sms": true, "phones_list": [ "+79001234567", "+79007654321" ], "message_text": "Alert! Speed limit exceeded in warehouse zone.", "webhook": true, "webhook_url": "https://yourdomain.com/webhook-handler", "ts": 1680000000, "te": 1710000000, "timezone": 3, "zone_rule": "in", "speed_rule": ">", "speed_value": 80, "speed_time": 15, "speed_time_units": "ss", "ignition_rule": "on", "geozones_rule": "in", "break_duration": 0, "break_time_units": "ss", "tag_name": "truck", "temperature_rule": ">", "temperature_value": 30, "temperature_time": 0, "disconnect_time": 0, "disconnect_time_units": "ss", "odometer_rule": ">", "odometer_value": 100000, "odometer_period": "abs" } }  
---|---  
  
## GET 

Fetches a notification configuration by its unique ID.

Required query parameter

  * id — ID of the notification




### Request example

| https://<server_address>/api/ptm/notification.php?id=123  
---|---  
  
### Response example

| { "success": true, "msg": "Notification retrieved", "method": "GET", "notification": { "id": 123, "agent_id": 123, "type": "speed", "geozones": [ { "name": "Warehouse", "zonetype": 1, "points": [ [55.7558, 37.6173], [55.7560, 37.6180], [55.7565, 37.6170] ] } ], "name": "Speeding in warehouse zone", "email": true, "emails_list": [ "dispatcher@example.com", "manager@example.com" ], "sms": true, "phones_list": [ "+79001234567", "+79007654321" ], "message_text": "Alert! Speed limit exceeded in warehouse zone.", "webhook": true, "webhook_url": "https://yourdomain.com/webhook-handler", "ts": 1680000000, "te": 1710000000, "timezone": 3, "zone_rule": "in", "speed_rule": ">", "speed_value": 80, "speed_time": 15, "speed_time_units": "ss", "ignition_rule": "on", "geozones_rule": "in", "break_duration": 0, "break_time_units": "ss", "tag_name": "truck", "temperature_rule": ">", "temperature_value": 30, "temperature_time": 0, "disconnect_time": 0, "disconnect_time_units": "ss", "odometer_rule": ">", "odometer_value": 100000, "odometer_period": "abs" } }  
---|---  
  
## PUT 

Updates an existing notification configuration.

Use the same format as in POST, but with the actual id of the notification to be updated.

Request address

| https://<server_address>/api/ptm/notification.php  
---|---  
  
###  Request body example

| { "id": 123, "agent_id": 123, "type": "speed", "geozones": [ { "name": "Warehouse", "zonetype": 1, "points": [ [55.7558, 37.6173], [55.7560, 37.6180], [55.7565, 37.6170] ] } ], "name": "Updated speed alert", "email": true, "emails_list": ["alerts@example.com"], "sms": false, "phones_list": [], "message_text": "Updated speed alert message", "webhook": false, "webhook_url": "", "ts": 1680000000, "te": 1720000000, "timezone": 3, "zone_rule": "in", "speed_rule": ">", "speed_value": 90, "speed_time": 10, "speed_time_units": "ss", "ignition_rule": "off", "geozones_rule": "in", "break_duration": 0, "break_time_units": "ss", "tag_name": "van", "temperature_rule": ">", "temperature_value": 35, "temperature_time": 0, "disconnect_time": 0, "disconnect_time_units": "ss", "odometer_rule": ">", "odometer_value": 120000, "odometer_period": "abs" }  
---|---  
  
###  Response example

| { "success": true, "msg": "Notification successfully updated", "method": "PUT", "notification": { "id": 123, "agent_id": 123, "type": "speed", "geozones": [ { "name": "Warehouse", "zonetype": 1, "points": [ [55.7558, 37.6173], [55.7560, 37.6180], [55.7565, 37.6170] ] } ], "name": "Updated speed alert", "email": true, "emails_list": ["alerts@example.com"], "sms": false, "phones_list": [], "message_text": "Updated speed alert message", "webhook": false, "webhook_url": "", "ts": 1680000000, "te": 1720000000, "timezone": 3, "zone_rule": "in", "speed_rule": ">", "speed_value": 90, "speed_time": 10, "speed_time_units": "ss", "ignition_rule": "off", "geozones_rule": "in", "break_duration": 0, "break_time_units": "ss", "tag_name": "van", "temperature_rule": ">", "temperature_value": 35, "temperature_time": 0, "disconnect_time": 0, "disconnect_time_units": "ss", "odometer_rule": ">", "odometer_value": 120000, "odometer_period": "abs" } }  
---|---  
  
## DELETE

Deletes one or more notification configurations.

Query parameters:

  * id (optional) — ID of the specific notification to delete

  * agent_id (optional) — Deletes all notifications for the specified agent




### Request examples

Delete a single notification:

|  https://<server_address>/api/ptm/notification.php?id=123  
---|---  
  
Delete all notifications for an agent:

| https://<server_address>/api/ptm/notification.php?agent_id=456  
---|---  
  
###  Response example

| { "count": 1 // Number of deleted notifications }  
---|---  
  
## Notification configuration fields description

Field |  Description  
---|---  
id |  Notification ID  
agent_id |  Agent ID (device or vehicle identifier)  
type |  Notification type (speed, temperature, ignition, etc.)  
geozones |  Array of geofences applicable to this notification  
name |  Notification name  
email |  Enable email alerts  
emails_list |  List of email addresses   
sms |  Enable SMS alerts  
phones_list |  List of phone numbers  
message_text |  Text message of the alert  
webhook_url |  Webhook endpoint URL  
webhook |  Enable webhook  
ts, te |  Start and end time of notification (Unix timestamp)  
timezone |  Time zone offset (e.g. +3)  
zone_rule |  Zone condition (in, out)  
speed_rule |  Speed condition (>, <, =)  
speed_value |  Speed threshold  
speed_time |  Duration of speed violation  
speed_time_units |  Time units: ss (seconds), mm (minutes), hh (hours)  
ignition_rule |  Ignition state (on, off)  
geozones_rule |  Zone behavior (in, out)  
break_duration |  Break duration  
break_time_units |  Time units for break: ss, mm, hh  
temperature_rule |  Temperature condition (>, <)  
temperature_value |  Temperature threshold   
temperature_time |  Duration of temperature violation (in units)  
disconnect_time |  Device disconnection duration  
disconnect_time_units |  Time units for disconnection  
odometer_rule |  Odometer condition (>, <, =)  
odometer_value |  Odometer value  
odometer_period |  Odometer mode (abs, rel)  
tag_name |  Object tag (e.g. "truck")

### Notification events — GET `notifications`
This API retrieves notification events for a selected period, such as speeding, leaving a geofence, or other pre-configured alerts.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=notifications — command to get notification events

  * ts — start time of the period (Unix timestamp)

  * te — end time of the period (Unix timestamp)

  * notification — name of the notification to retrieve events for

  * node— node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=notifications&ts=1606942800&te=1607115600&notification=test&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": [ { "vehiclenumber": "PS2", "agentid": 109792, "message": "Speed > 10 km/h longer than 10 sec max speed=52km/h Duration: 42 sec", "ts": 1606988609 }, { "vehiclenumber": "PS2", "agentid": 109792, "message": "Speed > 10 km/h longer than 10 sec max speed=29km/h Duration: 12 sec", "ts": 1606988438 }, { "vehiclenumber": "PS2", "agentid": 109792, "message": "Speed > 10 km/h longer than 10 sec max speed=17km/h Duration: 13 sec", "ts": 1606988106 } ], "id": 3701 }  
---|---  
  
In response to the API request, the following is returned:

  * vehiclenumber — vehicle registration number or internal number

  * agentid — object ID in the system

  * message — notification message text

  * ts — event time (Unix timestamp)

  * id— request/session identifier

### Object live events — GET `live_events`
This API returns real-time events (live events) for vehicles, including contract info, company, driver, speed, and event start location.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=live_events — command to get live events

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=live_events&node=1  
---|---  
  
Response

| { "1264": { "Contract Number": "CONTRACT ID", "Company Name": "Al Turki Enterprises", "Base Location": "LEK", "Vehicle Owner": "SUB-CONTRACTOR", "ID": 1680881937, "EventID, EventType": 0, "VehicleID": "5174 WA", "Asset Category": "Light", "Road Type": "Blacktop", "DriverID": 18262972, "Event Start Time": "1680881932", "Event Start Speed": 0, "Event Start Location": { "lat": "18.185841", "lon": "55.213230" } }, "1123": { "Contract Number": "", "Company Name": "Al Turki Enterprises", "Base Location": "", "Vehicle Owner": "", "ID": 1680881937, "EventID, EventType": 0, "VehicleID": "6076MB", "Asset Category": "Light", "Road Type": "Blacktop", "DriverID": 0, "Event Start Time": "1680881413", "Event Start Speed": 0, "Event Start Location": { "lat": "18.188658", "lon": "55.206314" } } }  
---|---  
  
In response to the API request, the following is returned:

  * Object Key (e.g., 1264, 1123) — unique event identifier

  * Contract Number — contract number

  * Company Name — company name

  * Base Location — vehicle base location

  * Vehicle Owner — vehicle owner

  * ID — internal event ID

  * EventID, EventType — event identifier and type

  * VehicleID — vehicle number or ID

  * Asset Category — vehicle category

  * Road Type — type of road

  * DriverID — driver ID

  * Event Start Time — event start time (Unix timestamp)

  * Event Start Speed — speed at event start

  * Event Start Location — coordinates of event start (lat, lon)

### Create waybill — GET `add_waybill`
This API creates a new waybill for a specified time period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=add_waybill — command to add a waybill

  * ts — start time (Unix timestamp)

  * te — end time (Unix timestamp)

  * agent_id — agent identifier

  * name — name of the waybill

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=add_waybill&ts=1596022528&te=1596488400&agent_id=44841&name=test+bill1&node=1  
---|---  
  
Response

| { "code": 0, "data": { "ts": 1596022528, "te": 1596488400, "agent_id": 44841, "account_id": 3934, "waybill": { "name": "test bill1" } } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * data — object with the created waybill data:

  * ts — waybill start time (Unix timestamp)

  * te — waybill end time (Unix timestamp)

  * agent_id — agent identifier

  * account_id — account identifier

  * waybill.name — name of the waybill

### Waybill information — GET `get_waybill`
This API allows you to get waybill data for a specified period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=get_waybill — command to get waybills

  * ts — start time of the selection period (Unix timestamp)

  * agent_id — agent identifier

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=get_waybill&ts=1596022528&agent_id=44841&node=1  
---|---  
  
Response

| { "code": 0, "data": [ { "ts": 1596022528, "te": 1596488400, "agent_id": 44841, "account_id": 3934, "waybill": { "name": "test bill1" } } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * data — array with waybill information:

  * ts — waybill start time (Unix timestamp)

  * te — waybill end time (Unix timestamp)

  * agent_id — agent identifier

  * account_id — account identifier

  * waybill — object containing waybill details:

  * name — name of the waybill

### Delete waybill — GET `remove_waybill`
This API deletes an existing waybill for a specified time period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=remove_waybill — command to remove a waybill

  * ts — start time (Unix timestamp)

  * te — end time (Unix timestamp)

  * agent_id — agent identifier

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=remove_waybill&ts=1596022528&te=1596488400&agent_id=44841&node=1  
---|---  
  
Response

| { "code": 0, "data": 1 }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * data — deletion result (1 = successfully deleted)

### Create user — GET `create_user`
This API allows you to create a new user in PILOT with specified parameters: login, password, role, and contact information.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET

### Request parameters

  * cmd=create_user — command to create a user

  * login — login of the new user

  * password — user password

  * name — user name

  * phone — user phone number

  * email— user email

  * role_id— user role: 0 — Admin, 1 — User

  * vehicles— list of accessible vehicles (IDs or quantity)

  * folders— list of accessible folders (IDs or quantity)

  * node— node number where the command should be executed




| The request must include the login and password of the administrator creating the user.  
---|---  
  
### Example request

| https://<server_address>/api/api.php?cmd=create_user&login=TestAPI3&password=123456&name=Test API&role_id=1&phone=789995&email=testapi5@mailinator.com&vehicles=15&folders=5&node=1  
---|---  
  
Response

| { "code": 0, "msg": "Success create user: 48" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 — successful operation)

  * msg — server message with the ID of the created user

### Update user login and password — GET `update_user_auth`
This API allows you to change the login and password of an existing user in the PILOT system.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET

### Request parameters

  * cmd=update_user_auth — command to update authentication data

  * login — new user login

  * password — new user password

  * user_id — ID of the user whose data should be changed

  * node — node number where the command should be executed 




### Example request

| https://<server_address>/api/api.php?cmd=update_user_auth&login=TestAPI&password=qwerty&user_id=48&node=1  
---|---  
  
Response

| { "code": 0, "msg": "Success" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 — successful operation)

  * msg — server message about the result of the action

### Delete user — GET `remove_user`
This API deletes an existing user in the PILOT system by their user ID.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

DELETE

### Request parameters

  * cmd=remove_user — command to delete a user

  * user_id — ID of the user to be removed

  * node — node number where the command should be executed (optional)




### Example request

| https://<server_address>/api/api.php?cmd=remove_user&user_id=48&node=1  
---|---  
  
Response

| { "code": 0, "msg": "Success remove" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 — successful operation)

  * msg — server message about the result of the action

### User information — GET `get_user`
This API retrieves detailed information about a user by their user_id.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

  * cmd=get_user — API command to get user information

  * user_id — identifier of the user whose information should be retrieved

  * node — node number where the command should be executed




### Example GET request

| https://<server_address>/api/api.php?cmd=get_user&user_id=19&node=1  
---|---  
  
### Example POST request

Request body (JSON):

| { "cmd": "get_user", "user_id": 19 }  
---|---  
  
Response

| { "code": 0, "msg": "Success", "data": { "id": 19, "roleid": 1, "info": "", "msisdn": "123123", "email": "testTOTP@testTOTP.com", "name": "dasd", "account_id": 1000, "lang": "en", "parent_id": 2 } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = successful operation)

  * msg — server message

  * data — user information object:

  * id — user ID

  * roleid — user role (0 = Admin, 1 = User)

  * info — additional user information

  * msisdn — phone number

  * email— user’s email address

  * name — user’s name

  * account_id — account ID the user belongs to

  * lang — user interface language

  * parent_id— parent user ID (if any)

### User list of own account — GET `get_account_user_list`
This API is used to retrieve a list of all users registered under your account.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

  * cmd=get_account_user_list — API command to get the list of account users

  * node — node number where the command should be executed




### Example GET request

| https://<server_address>/api/api.php?cmd=get_account_user_list&node=1  
---|---  
  
### Example POST request

Request body (JSON):

| { "cmd": "get_account_user_list" }  
---|---  
  
Response

| { "code": 0, "data": [ { "id": 19, "roleid": 1, "info": "", "msisdn": "123123", "email": "testTOTP@testTOTP.com", "name": "dasd", "account_id": 1000, "lang": "en", "parent_id": 2 } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = successful operation)

  * data — array of account users:

  * id — user identifier

  * roleid — user role (0 = Admin, 1 = User, 2 = Logistic, etc.)

  * info — additional information

  * msisdn — phone number

  * email — user’s email address

  * name — user’s name

  * account_id — account ID the user belongs to

  * lang — user interface language

  * parent_id — parent user ID (if any)

### Accessible accounts list — GET `get_account_map`
This API is used to retrieve the list of accounts that the currently authorized user has access to.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

  * cmd=get_account_map — API command to retrieve the list of accessible accounts

  * node — node number where the command should be executed




### Example GET request

| https://<server_address>/api/api.php?cmd=get_account_map&node=1  
---|---  
  
### Example POST request

Request body (JSON):

| { "cmd": "get_account_map" }  
---|---  
  
Response

| { "code": 0, "data": [ {"account_id": 1005}, {"account_id": 1000} ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — execution result (0 indicates a successful operation)

  * data — list of accounts accessible to the user

  * account_id — unique identifier of the account

### User folders list — GET `get_folders_user`
This API returns a list of folders that the user has access to in the account.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

  * cmd=get_folders_user — command to get the list of folders

For POST requests, parameters can be sent in the request body as JSON

  * node — node number where the command should be executed 




### Example GET request

| https://<server_address>/api/api.php?cmd=get_folders_user&node=1  
---|---  
  
Response

| { "code": 0, "msg": "Success", "data": [ {"id":1,"name":"DEMO"}, {"id":6,"name":"IP Emelyanov"}, {"id":11,"name":"FOLDER1"}, {"id":12,"name":"FOLDER2"} ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 — successful operation)

  * msg — server message

  * data — array of user folders:

  * id — folder ID

  * name — folder name

### Other user’s folders list — GET `get_folders_user`
This API returns the folders accessible to a specified user.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

  * cmd=get_folders_user — command to get the list of folders

  * user_id — user ID (required when requesting folders for another user)

  * node — node number where the command should be executed (optional)

For POST requests, parameters can be sent in the request body as JSON




### Example GET request

| https://<server_address>/api/api.php?cmd=get_folders_user&user_id=19&node=1   
---|---  
  
### Example POST request

| { "cmd": "get_folders_user", "user_id": 19 }  
---|---  
  
Response

| { "code": 0, "msg": "Success", "data": [ {"id":1,"name":"DEMO"}, {"id":6,"name":"IP Emelyanov"}, {"id":11,"name":"FOLDER1"}, {"id":12,"name":"FOLDER2"} ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 — successful operation)

  * msg — server message

  * data — array of folders accessible to the user:

  * id — folder ID

  * name — folder name

### Update folder list — POST `update_user_folders`
This API allows updating the set of folders accessible to a specific user.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

POST

### Request parameters

  * cmd=update_user_folders — command to update the folder list

  * folders — comma-separated list of folder IDs to assign to the user

  * user_id — ID of the user whose folder access is being updated




### Example request

| { "cmd": "update_user_folders", "folders": "1,11", "user_id": 19 }  
---|---  
  
Response

| { "code": 0, "msg": "Success" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 — successful operation)

  * msg — server message describing the result of the action

### Update user’s accessible accounts — POST `update_user_accounts_map`
This API allows assigning a user access to specific accounts. If a partner in the system has multiple accounts, an administrator can choose which accounts a particular user can access.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

POST

### Request parameters

  * cmd=update_user_accounts_map — command to update the list of accessible accounts

  * accounts — comma-separated list of contract IDs (accounts) to assign to the user

| Accounts must belong to the same partner as the user.  
---|---  
  
  * user_id — ID of the user to whom the contracts are assigned

  * node — node number where the command should be executed 




| If the user’s partner ID in the system is 0, assigning contracts is not possible (mapping will not work).  
---|---  
  
### Example request

| { "cmd": "update_user_accounts_map", "accounts": "1005", "user_id": 19 }  
---|---  
  
Response

| { "code": 0, "msg": "Success" }  
---|---  
  
In response to the API request, the following is returned:

  * code— result code (0 indicates a successful operation)

  * msg— server message confirming the result

### Update user vehicles — POST `update_user_vehicles`
This API assigns a user access only to the selected vehicles.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

POST

### Request parameters

  * cmd=update_user_vehicles — command to update the list of vehicles

  * vehicles — comma-separated list of vehicle IDs 

  * user_id — ID of the user whose access is being updated

  * node— node number where the command should be executed




### Example request

| { "cmd": "update_user_vehicles", "vehicles": "2,18", "user_id": 19 }  
---|---  
  
Response

| { "code": 0, "msg": "Success" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = successful operation)

  * msg — server message

### Equipment management — GET `sensors`
This API allows you to retrieve sensor activity data for a vehicle over a selected period. Using it, you can:

— track periods when sensors were active (e.g., ignition, equipment turned on)

— obtain location data when a sensor was triggered

— analyze vehicle behavior and equipment usage

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=sensors — command to get sensor data

  * imei — vehicle identifier in the system

  * start — start time of the period (Unix timestamp)

  * stop — end time of the period (Unix timestamp)

  * node — node number where the command is executed




### Example request

| https://<server_address>/api/api.php?cmd=sensors&imei=356307046690011&start=1404637430&stop=1404645198&node=1  
---|---  
  
Response

Each sensor is represented as an object where the key is the sensor ID in the system:

| "sensors": { "9175": { "fieldname": "DIS1", "info": "Ignition sensor", "id": 9175, "work": { "1404637430": { "ts": 1404637430, "te": 1404637834, "lat": "46.3825", "lon": "48.0031", "place": "Russia, Astrakhan Region, Narimanovsky District, Nikolaevskoye Highway, 1b" }, "1404638577": { "ts": 1404638577, "te": 1404639841, "lat": "46.3625", "lon": "48.0478", "place": "RU, Astrakhan, Savushkina Street" } // ... more sensor activity periods } } }  
---|---  
  
In response to the API request, the following is returned:

  * fieldname — sensor field name in the system (e.g., DIS1)

  * info — sensor description in the system (e.g., "Ignition sensor")

  * id — sensor ID in the system

  * work — object containing sensor activity periods; keys are start times (ts)

  * ts — sensor activation time (Unix timestamp)

  * te — sensor deactivation time (Unix timestamp)

  * lat — latitude when the sensor was activated

  * lon — longitude when the sensor was activated

  * place — address or location when the sensor was triggered

### Sensor values — GET `get_discrete_sensor_data`
This API retrieves values of discrete sensors (fuel level, temperature, weight, etc.) for a specified period of time.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET

### Request parameters

  * cmd=get_discrete_sensor_data — command to get sensor data

  * imei — object identifier

  * start — start of the period (Unix timestamp)

  * stop — end of the period (Unix timestamp)

  * tag_id — sensor identifier

  * agent_id — agent identifier (optional)

  * node— node number where the command should be executed




| Sensor data can only be retrieved for up to 24 hours.  
---|---  
  
### Example request

| https://<server_address>/api/api.php?cmd=get_discrete_sensor_data&imei=350424062310402&start=1677682645&stop=1677761845&tag_id=1158&node=1  
---|---  
  
Response

| { "sensor_data": { "966960": { "1677682772": { "sensor_id": 966960, "unixtimestamp": 1677682772, "calibrated_value": "95.09", "speed": "0" }, "1677682950": { "sensor_id": 966960, "unixtimestamp": 1677682950, "calibrated_value": "94.9", "speed": "12" } } } }  
---|---  
  
In response to the API request, the following is returned:

  * sensor_id — sensor identifier

  * unixtimestamp — time of the recorded value (Unix timestamp)

  * calibrated_value — calibrated sensor value (e.g., liters of fuel or degrees of temperature)

  * speed — speed of the object at the moment of measurement

### Battery charge by VIN — POST `vehicle`
This API retrieves battery charge information for a vehicle based on its VIN.

It works only for vehicles that meet the following conditions:

— the VIN field is filled in the vehicle card

— a battery charge sensor is connected

| You can specify multiple VINs in a single request. The response will include battery data for all specified vehicles.  
---|---  
  
## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/VTB/api_vtb.php

### Request method

POST

The API requires two steps:

1\. Authorization — obtain a token to access data

2\. Data Request — use the token to retrieve battery information by VIN

### 1\. Authorization

Before requesting data, you must authenticate.

Request Body:

| { "login": "your_login", "password": "your_password", "cmd": "auth" }  
---|---  
  
Response

| { "token": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" }  
---|---  
  
The response contains a token, which is a long unique string. This token is required for all subsequent API requests. Without it, the API will not return battery data.

### 2\. Retrieving battery sensor data

After obtaining the token, you can request battery information.

Request parameters:

  * Number — list of VINs for vehicles you want to query

  * DateFrom — start date and time (ISO 8601 format)

  * DateTo — end date and time (ISO 8601 format)

  * cmd=vehicle — API command to request vehicle data




Request headers:

  * Authorization: Bearer <token>— include the token obtained during authorization

  * Content-Type: application/json— specify that the request body is JSON




Request body example:

| { "Number": ["VIN_of_vehicle"],  "DateFrom": "2023-12-03T00:00:00", "DateTo": "2023-12-12T00:00:00", "cmd": "vehicle" }  
---|---  
  
Response

| [ { "Number": "456789123", "ApplicationNumber": null, "CurrentStatus": "ACTIVE", "CloseDateTime": "", "LastSyncDate": "2024-08-28 15:42:45", "AlarmDateTime": "2024-08-28 15:42:45", "Latitude": "55.578352", "Longitude": "38.125267", "BatteryCharge": "full charge", "LocationLinesID": "", "FullAddress": "ulitsa Garnaeva, Market, Zhukovsky, Moscow Region, Russia", "Country": "Russia", "Region": "Moscow Region", "Town": "Zhukovsky", "Street": "ulitsa Garnaeva", "House": null, "numberRegion": 10 } ]  
---|---  
  
In response to the API request, the following is returned:

  * Number — VIN of the vehicle

  * CurrentStatus — current status of the vehicle

  * LastSyncDate — date of last synchronization

  * BatteryCharge — battery charge level

  * FullAddress, Country, Region, Town, Street — location of the vehicle

  * Latitude, Longitude — coordinates of the vehicle

### IMEI by vehicle number — GET `get_imei`
This API allows you to determine the IMEI of the device installed in a vehicle by its number.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=get_imei— API command

  * vehnum — vehicle number

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=get_imei&vehnum=IX35&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "imei": "356307045913463" }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success, other values = error)

  * msg — server message

  * imei — IMEI of the device installed in the vehicle

### Raw data by IMEI — GET `ag_events`
This API allows you to get raw device data for a specified time period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=ag_events — API command to get raw points

  * imei — unique device identifier

  * ts — start time of the data (Unix timestamp)

  * te — end time of the data (Unix timestamp)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=ag_events&ts=1498201000&te=1498201200&imei=356307045913463&node=1  
---|---  
  
Response

| { "code": 0, "data": { "1498201016": {"alt": 33, "lat": "47.2124", "lon": "39.6922", "sat": 15, "speed": 0, "ts": 1498201016}, "1498201037": {"alt": 29, "lat": "47.2124", "lon": "39.6924", "sat": 15, "speed": 6, "ts": 1498201037}, "1498201097": {"alt": 31, "lat": "47.2128", "lon": "39.6933", "sat": 15, "speed": 0, "ts": 1498201097} }, "msg": "OK", "vehicle": { "agentid": 2914, "created_time": 1359797592, "current_mileage": 90224, "folder": "Sky Electronics", "imei": "356307045913463", "type": "Cow", "typeid": 31, "vehiclenumber": "IX35" } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success, other values = error)

  * msg — server message

  * data — object containing raw points, where keys are timestamps and values:

  * lat — latitude

  * lon — longitude

  * alt — altitude

  * sat — number of satellites

  * speed — speed

  * ts — event timestamp (Unix)

  * vehicle — information about the object:

  * agentid — agent identifier

  * created_time — object creation time

  * current_mileage — current mileage

  * folder — folder/group name

  * imei — device identifier

  * type — object type

  * typeid — object type ID

  * vehiclenumber — vehicle number

### iButton list — GET `take_ibutton_list`
This API retrieves a list of iButtons assigned to a vehicle for a specified period.

An iButton is a small electronic device (tag) used to identify drivers or objects. It is typically applied for access control, work time tracking, or recording the start/end of vehicle usage.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=take_ibutton_list — command for the API to get the iButton list

  * ts — start date of the period (Unix timestamp)

  * te — end date of the period (Unix timestamp)

  * agentId— vehicle identifier

  * node — node number where the command is executed




### Example request

| https://<server_address>/api/api.php?cmd=take_ibutton_list&ts=1643662800&te=1645045200&AgentID=79673&node=1  
---|---  
  
Response

| { "code": 0, "msg": "OK", "data": [ { "ibutton": "ae00001000000000", "ts": 1643680128 }, { "ibutton": "ae00001000000001", "ts": 1643680128 } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * msg — server message (e.g., "OK")

  * data — array with information about iButtons:

  * ibutton — unique iButton identifier

  * ts— timestamp when the iButton was registered (Unix timestamp)

### Passenger flow — GET `pass_counter`
This API is used to retrieve data on passenger flow in vehicles equipped with the Autoconductor system.

With it, you can:

— see how many passengers boarded and exited at each stop

— get stop coordinates, event timestamps, and a video identifier (if video recording is supported by the system)

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=pass_counter — command to call the API

  * ts — start time of the selection period (Unix timestamp)

  * te — end time of the selection period (Unix timestamp)

  * node — node number where the command is executed

  * imei (optional) — IMEI of the vehicle equipped with Autoconductor. If not specified, the selection will include all vehicles with the system




## Example request

| https://<server_address>/api/api.php?cmd=pass_counter&ts=1554670800&te=1554757200&imei=963852741159753&node=1  
---|---  
  
Response

| { "code": 0, "data": { "36571": { "agent_id": 36571, "stops": [ { "busline_id": 1371, "door_id": 0, "lat": "54.9346", "lon": "51.8981", "p_in": 1, "p_out": 0, "ts": 1554696995, "video_id": 13 }, { "busline_id": 1371, "door_id": 0, "lat": "54.9238", "lon": "51.9098", "p_in": 4, "p_out": 0, "ts": 1554697232, "video_id": 14 } ], "vehiclenumber": "autoconductor" } }, "msg": "OK" }  
---|---  
  
In response to the API request, the following is returned:

  * code — execution code (0 = success)

  * msg — status message (e.g., OK)

  * data — main object containing passenger flow data

  * agent_id — vehicle ID in the system

  * vehiclenumber — internal vehicle number or equipment name (e.g., autoconductor)

  * stops — array of stops with passenger flow data:

  * busline_id — route ID

  * door_id — door number where passenger movement was recorded

  * lat — stop latitude

  * lon — stop longitude

  * p_in — number of passengers boarded

  * p_out — number of passengers exited

  * ts — event time (Unix timestamp)

  * video_id — video recording ID linked to the event (if available)

### Bus route management — POST `bindControl`, `bindLineToVeh`, `listLines`, `setLine`, `unbindControl`
This API is used for managing bus routes and assigning vehicles to routes. It allows you to create routes, assign vehicles to trips, and manage route bindings.

## How to get data

### Method

POST

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

Request parameters:

  * cmd — the command to execute

  * data — JSON object with parameters specific to the command




Available commands:

  * setLine — create a new bus route

  * bindControl — bind a vehicle to a route

  * bindLineToVeh — bind a route to a vehicle by route ID

  * unbindControl — remove a vehicle binding

  * listLines — get the list of routes

  * setControl — assign a bus to a trip

  * unsetControl — remove the assignment




### Creating a bus route (setLine)

Request address

| https://<server_address>/api/api.php?cmd=setLine  
---|---  
  
Request body example

| { "account_id": "3008", "bidirectional": 1, "description": "Route #9", "label": "123", "name": "Route #9", "number": "12304", "type_id": 0, "uid": "dhqwdh", "points": [ { "lat": "45.0207", "lon": "33.9993", "name": "Airport", "price": 15.35, "radius": "91", "silent": 0, "stop_type": 0, "ts": 600, "te": 700, "uid": "819897e2-843b-11e4-bf52-002354656fea" }, { "lat": "44.9078", "lon": "34.0784", "name": "7th City Hospital", "price": 15.35, "radius": "90", "silent": 0, "stop_type": 0, "ts": 900, "te": 1000, "uid": "819897e8-843b-11e4-bf52-002354656fea" } ] }  
---|---  
  
Route parameters:

Parameter |  Type |  Description  
---|---|---  
account_id |  string |  Account ID  
bidirectional |  number |  1 = round-trip, 0 = one-way  
description |  string |  Route description  
label |  string |  Optional route label  
name |  string |  Route name  
number |  string |  Route number  
type_id |  number |  Vehicle type (0=bus, 1=trolleybus, 2=tram, 3=minibus)  
uid |  string |  Unique route ID  
points |  array |  Stops on the route  
  
Stop parameters:

Parameter |  Type |  Description  
---|---|---  
lat |  string |  Stop latitude  
lon |  string |  Stop longitude  
name |  string |  Stop name  
price |  number |  Fare from previous stop  
radius |  string |  Stop radius in meters  
silent |  number |  1 = no notifications, 0 = notifications allowed  
stop_type |  number |  0 = regular, 1 = technical, 2 = terminal  
ts |  number |  Arrival time relative to previous stop (seconds)  
te |  number |  Stop duration (seconds)  
uid |  string |  Unique stop ID  
  
Response 

| { "status": "success", "message": "Route created successfully", "data": { "uid": "dhqwdh", "lineuid": "2567" } }  
---|---  
  
### Binding a vehicle to a route (bindControl)

Request address

| https://<server_address>/api/api.php?cmd=bindControl  
---|---  
  
Request body example

| { "uid": "121e1e1e12", "imei": "12304", "lineuid": "2e23e23e2e", "ts": "1392294840", "te": "1392321600", "message_url": "http://example.com/message.php", "prognoze_url": "http://example.com/prognoze.php" }  
---|---  
  
Parameters:

Parameter |  Type |  Description  
---|---|---  
uid |  string |  Unique binding ID  
imei |  string |  Vehicle IMEI  
lineuid |  string |  Route UID  
ts |  string |  Start timestamp  
te |  string |  End timestamp   
message_url |  string |  Event notification URL  
prognoze_url |  string |  Stop arrival forecast URL  
  
Response 

| { "status": "success", "message": "Binding created successfully", "data": { "uid": "121e1e1e12", "imei": "12304", "lineuid": "2e23e23e2e" } }  
---|---  
  
### Simplified binding by route ID (bindLineToVeh)

Request address

| https://<server_address>/api/api.php?cmd=bindLineToVeh  
---|---  
  
Request body example

| { "data": { "imei": "12304", "lineid": "12345", "ts": "1392294840" } }  
---|---  
  
Response 

| { "code": 0, "msg": "OK", "data": { "imei": "12304", "lineid": "12345" } }  
---|---  
  
### Unbinding a vehicle (unbindControl)

Request address

| https://<server_address>/api/api.php?cmd=unbindControl  
---|---  
  
Request body example

| { "uid": "qiwduhqiwdqkdqkn" }  
---|---  
  
  * uid — unique identifier of the binding




Response 

| { "status": "success", "message": "Binding removed", "data": { "uid": "qiwduhqiwdqkdqkn" } }  
---|---  
  
### Getting the list of routes (listLines)

Request address

| https://<server_address>/api/api.php?cmd=listLines  
---|---  
  
Response 

| { "code": 0, "msg": "OK", "data": [ { "id": 2955, "name": "125K", "number": "125K", "bidirectional": 1, "description": "125K", "account_id": 18306, "active": 1, "type_id": 0 } ] }  
---|---  
  
### Combined route creation and vehicle assignment

Request body example

| { "uid": "qiwduhqiwdqkdqkn", "ts": "1392294840", "te": "1392321600", "name": "test", "imei": "359772039289781", "number": "861A", "message_url": "http://example.com/message.php", "prognoze_url": "http://example.com/prognoze.php", "points": [ { "uid": "1", "lat": "53.352142", "lon": "83.758749", "name": "Barnaul Bus Station", "radius": "50", "stop_type": 0, "price": 15.35 }, { "uid": "2", "lat": "52.534012", "lon": "85.178777", "name": "Biysk Bus Station", "radius": "100", "stop_type": 0, "price": 15.35 } ] }  
---|---  
  
Response

| { "status": "success", "message": "Route and binding created successfully", "data": { "uid": "qiwduhqiwdqkdqkn", "imei": "359772039289781", "lineuid": "2e23e23e2e" } }  
---|---

### Bus status — GET `currentBusState`
This API returns the current status of a bus: its route, the current and next stops, as well as route information (number, fare, interval, etc.).

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=currentBusState — command to get the bus status

  * vehnum — bus number

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=currentBusState&vehnum=А%20086%20КХ%20116%20RUS&node=1  
---|---  
  
Response

| { "code": 0, "lines": [ { "id": 1086, "name": "1A", "number": "1A", "bidirectional": 1, "description": "1A", "active": 1, "price": "25.00", "interval": 10, "folder": null, "currentstop_id": 0, "currentstop_order": 0, "nextstop_id": 5217, "nextstop_order": 48 } ] }  
---|---  
  
In response to the API request, the following is returned:

  * id — route ID

  * name — route name

  * number — route number

  * bidirectional — route direction flag (1 = bidirectional, 0 = one-way)

  * active — route activity flag (1 = active)

  * price — fare price

  * interval — interval between buses in minutes

  * currentstop_id — ID of the stop where the bus is currently located

  * currentstop_order — sequence number of the current stop

  * nextstop_id — ID of the next stop

  * nextstop_order — sequence number of the next stop

### Vehicle arrival forecast at stop — GET `stationForecast`
This API provides the predicted arrival time of buses, trolleybuses, and minibuses at a specified stop.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=stationForecast — command to get the arrival forecast

  * stopid — identifier of the stop (taken from the PILOT interface)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=stationForecast&stopid=7400&node=1  
---|---  
  
Response

| [ { "curent_stop": 1, "line_id": 1371, "line_name": "№ 17 S. KALFA - PL. SUVOROVA - UL. GENERAL ZHIDILOVA", "line_num": "17", "line_type": "A", "this_stop": 32, "time": 4065, "vehicle": "BUS FLIGHT", "vehid": 48854 } ]  
---|---  
  
The API returns an array of objects with forecasts for each route at the specified stop:

  * curent_stop — sequential number of the stop on the route where the vehicle is currently located

  * line_id — route ID

  * line_name — full name of the route

  * line_num — route number

  * line_type — type of route: 'A' — bus, 'T' — trolleybus, 'M' — minibus

  * this_stop — sequential number of this stop on the route

  * time — predicted arrival time at this stop (seconds)

  * vehicle — vehicle registration number

  * vehid — vehicle ID

### Route stop list — GET `stopList`
This API returns all stops for a given route, including coordinates, stop type, order, and fare information.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=stopList — command to get stop list

  * line_num — route number

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=stopList&line_num=1Б&node=1  
---|---  
  
Response

| { "code": 0, "line": { "id": 1083, "name": "1Б", "number": "1Б", "bidirectional": 1, "description": "1Б", "active": 1, "price": "25.00", "interval": 25, "folder": null, "stops": [ { "id": 5085, "name": "Центр занятости", "lat": "54.9036", "lon": "52.3315", "radius": 60, "stop_type": 0, "descr": null, "stop_order": 1, "price": "0.00", "ts": 0, "te": 0, "dir": 0, "silent": 0 }, { "id": 5086, "name": "Автовокзал", "lat": "54.9039", "lon": "52.3236", "radius": 60, "stop_type": 2, "descr": null, "stop_order": 2, "price": "0.00", "ts": 0, "te": 0, "dir": 0, "silent": 0 } ] } }  
---|---  
  
In response to the API request, the following is returned:

  * line.id — unique route ID

  * line.name — route name

  * line.number — route number

  * bidirectional — 1 if the route is bidirectional

  * active — 1 if the route is active

  * price — fare for the route

  * interval — interval between vehicles in minutes

  * stops — array of route stops:

  * id — unique stop ID

  * name — stop name

  * lat, lon — stop coordinates

  * radius — stop zone radius in meters

  * stop_type — stop type: 0 — normal, 1 — technical, 2 — terminal

  * stop_order — order of the stop in the route

  * silent — 1 to not generate notifications for this stop

### Route calculation and estimated arrival time — GET `route`
This API builds a route between two points and provides the estimated arrival time depending on the selected transport mode.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

  * cmd=route — command to build the route

  * mode — transport type, one of:

  * bicycle — bicycle

  * bus — bus

  * car — car

  * pedestrian — pedestrian

  * scooter — scooter

  * taxi — taxi

  * truck — truck

  * origin — starting point coordinates (lat,long)

  * destination — destination point coordinates (lat,long)

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=route&mode=bus&origin=47.211908,39.613767&destination=47.201699,39.668183&node=1  
---|---  
  
Response 

| { "code": 0, "data": { "routes": [ { "id": "79de74af-5040-441a-ab7a-62d3d9f7a4b4", "sections": [ { "id": "2cc5fff7-fd4f-43ac-bcda-00d662207c63", "type": "vehicle", "departure": { "time": "2023-02-22T09:40:07+03:00", "place": { "type": "place", "location": { "lat": 47.2119, "long": 39.61372 }, "originalLocation": { "lat": 47.211908, "long": 39.613767 } } }, "arrival": { "time": "2023-02-22T09:52:32+03:00", "place": { "type": "place", "location": { "lat": 47.2017113, "long": 39.668221 }, "originalLocation": { "lat": 47.201699, "long": 39.668183 } } }, "summary": { "duration": 745, "length": 5452, "baseDuration": 530 }, "transport": { "mode": "bus" } } ] } ] } }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = success)

  * routes — list of calculated routes

  * sections — route segments containing:

  * departure / arrival — departure and arrival times and coordinates

  * summary — trip duration and distance

  * transport.mode — selected transport type

### Rental contracts list — GET `rentcar_contracts`
This API provides information about rental contracts from the Rent Car module, including open, booked, and closed contracts.

For each contract, the response includes details about the renter, pickup and drop-off locations, planned start and end dates, as well as contract and vehicle numbers.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

To retrieve the required data, add the following parameters to the request URL:

  * cmd=rentcar_contracts — command to get the list of rental contracts

  * status — contract status(es) to retrieve. You can pass one or multiple values separated by commas:

  * open — active contracts (rental is currently ongoing)

  * booked — reserved contracts (booking created, rental not started yet)

  * closed — completed contracts (rental finished)




Response format: array of rental contracts

### Example request

| https://<server_address>/api/api.php?cmd=rentcar_contracts&status=open,booked,closed  
---|---  
  
Response example

| { "code": 0, "msg": "OK", "list": [ { "driver_name": "Test renter", "driver_phone": "905074521698", "end_location": { "title": "Dubai" }, "start_location": { "title": "Dubai" }, "mva": "12312", "ra": "16", "te_expected": 1775901540, "ts_expected": 1775812680, "plate_number": "Private house" }, { "driver_name": "Test renter", "driver_phone": "905074521698", "end_location": { "title": "rgergrr" }, "start_location": { "title": "erterter" }, "mva": "2222", "ra": "17", "te_expected": 1775901540, "ts_expected": 1775812680, "plate_number": "ABC-123" } ] }  
---|---  
  
The API response includes:

  * code — status code (0 = success)

  * msg — status message ("OK" = request successful)

  * list — array of rental contracts, where each contract contains:

  * driver_name — name of the renter (driver)

  * driver_phone — renter’s contact phone number

  * start_location — rental start location (vehicle pickup):

  * title — name/address of the pickup location

  * end_location — rental end location (vehicle return):

  * title — name/address of the return location

  * mva — Master Vehicle Agreement number

  * ra — Rental Agreement / booking number

  * ts_expected — planned rental start time (Unix timestamp)

  * te_expected — planned rental end time (Unix timestamp)

  * plate_number — vehicle license plate number associated with the contract

### Eco-driving data — GET `mileco_drive`, `milecodrive`
This API allows you to obtain detailed information about the eco-friendliness of vehicle driving over a specified period.

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request parameters

To get the required data, add parameters to the request address. Parameters are specified after the question mark ? and are separated by the ampersand &.

  * cmd = mileco_drive — command to obtain trip data

  * start — date and time of the start of the period for which you want to obtain data

  * stop — date and time of the end of the period

Time is specified in Unix timestamp format — the number of seconds that have elapsed since January 1, 1970.

  * vehid — the identifier of the vehicle. If you need data for one vehicle — enter its ID, if for several vehicles — list their IDs separated by commas. 

| f you do not specify the vehid parameter, the system will automatically provide information for all vehicles assigned to your account.  
---|---  
  
  * imei — a unique number of the vehicle's GPS tracker. Use this parameter to obtain data for a specific tracker. 

| When specifying imei, it is not necessary to indicate the vehid parameter.  
---|---  
  
Example API request with imei:




|  https://<server_address>/api/api.php?cmd=milecodrive&start=1738113401&stop=1738631801&timediff_type=1&imei=8664566839031889725   
---|---  
  
  * time_diff_type — grouping data by time. By default, data is collected for each day.

  * time_diff_type=1 — data will be collected for every 7 days

  * time_diff_type=2 — data will be collected for each month

  * node — node number where the command should be executed




### Example request

| https://<server_address>/api/api.php?cmd=mileco_drive&start=1738113401&stop=1738631801&time_diff_type=1&vehid=32,53&node=1  
---|---  
  
Response

| { "32": { "29.01.2025_01:16|04.02.2025_01:16": { "date": "Wednesday, 29.01.2025 01:16 - Tuesday, 04.02.2025 01:16", "veh_id": 32, "distance": 842.75354055, "agent_id": 545, "account_id": 10025, "account_name": "IP Ivanov", "veh_name": "О 511 ГР 123", "veh_type": "Car", "eco_data": { "speed": { "msg": "Speed", "cnt": 0, "val": 1290, "fee": 12 } } } } "53": { "29.01.2025_01:16|04.02.2025_01:16": { "date": "Wednesday, 29.01.2025 01:16 - Tuesday, 04.02.2025 01:16", "veh_id": 53, "distance": 8.24949075, "agent_id": 545, "account_id": 10025, "account_name": "IP Ivanov", "veh_name": "О 619АК 67", "veh_type": "Bus", "eco_data": [] } }  
---|---  
  
In response to the API request, data about vehicle is returned:

  * veh_id — vehicle identifier

  * imei — a unique number of the tracker

  * distance — distance traveled during the specified period

  * agent_id — contract identifier

  * account_id — account number in the system

  * account_name — account name

  * veh_name — name of the vehicle

  * veh_type — type of vehicle

  * eco_data — driving data

### Timezone list — GET `get_time_zones`
This API returns a list of available time zones that can be used when configuring a user or an object.

## How to get data

### Request address

To get the data, use the address: https://<server_address>/api/api.php?

### Request method

GET or POST

### Request parameters

  * cmd=get_time_zones — API command to retrieve the list of time zones

  * node — node number where the command should be executed




### Example GET request

| https://<server_address>/api/api.php?cmd=get_time_zones&node=1  
---|---  
  
### Example POST request

Request body (JSON):

| { "cmd": "get_time_zones" }  
---|---  
  
Response

| { "code": 0, "data": [ { "text": "Africa/Abidjan" }, { "text": "Africa/Accra" }, { "text": "Africa/Addis Ababa" }, { "text": "Africa/Algeria" }, { "text": "Africa/Asmara" }, { "text": "Africa/Bamako" }, { "text": "Africa/Bangui" } ] }  
---|---  
  
In response to the API request, the following is returned:

  * code — result code (0 = successful operation)

  * data — list of available time zones

  * text— time zone name in the format Region/City



## PILOT Task Manager API

### PILOT Task manager — GET 
**PILOT Task Manager (PTM)** is a module within the PILOT system designed for task management. It acts as an electronic dispatcher and task manager: here you create tasks, assign performers, and track their completion.

With PTM, you can:

  * Create and assign tasks

  * Plan work by dates and routes

  * Monitor task status and deadlines

  * Work with reports and the calendar




Who uses PTM:

  * Dispatchers and logisticians: Plan and assign tasks

  * Drivers and performers: Receive tasks and mark them as completed

  * Managers: View reports and results




| Access to PTM functions depends on your role and permissions. If you have administrator rights, you will have access to all functions. For users with limited permissions, only the necessary set of features for their work will be visible. If you need access to additional functions, please contact support.  
---|---  
  
| Watch the video to learn [how to activate PTM and log in](<https://youtu.be/kaGysSXxSFM>). <https://youtu.be/kaGysSXxSFM>  
---|---  
  
## In this section 

[How to log in to PTM](<how_to_log_in_to_ptm.html>)

[Interface overview](<interface_overview_2.html>)

[Dashboard ](<dashboard_.html>)

[How to create a task](<how_to_create_a_task.html>)

[Actions with tasks](<actions_with_tasks.html>)

[Driver reports](<driver_reports.html>)

[Users](<users_1.html>)

[Queue](<queue.html>)

[Dictionary](<dictionary_2.html>)

[Settings](<settings_2.html>)

[Calendar](<calendar.html>)

[Private office](<private_office.html>)

### Creating a task — POST 
This API is designed for creating tasks related to contracts where the PTM module is enabled.

Base API Path:

| /backend/public/api/task  
---|---  
  
### Request address

To make a request, use the following URL format:

| https://<server_address>/backend/public/api/task  
---|---  
  
### API Access

API access is authenticated using HTTP Basic authentication. The username and password should be formatted as:

| username_from_PILOT:password_from_PILOT  
---|---  
  
### Example API request

| https://demo:demo@tasks.pilot-gps.com/backend/public/api/task/create_universal  
---|---  
  
### API Response format

The API response is standardized and has the following format:

| { "success": true, // TRUE - successful request, FALSE - error "msg": "OK", // Error message, if any "httpCode": 200, // Error code "data": [], // Response data, if available "et": 0, // Request execution time "exceptionMsg": "Exception" // Exception message, if any }  
---|---  
  
### Status codes and error codes

  * 200 — Successful request

  * 400 — Missing required parameters

  * 401 — Authorization error: Incorrect username or password

  * 404 — API route not found

  * 500 — Server error




### How to create a task

Request method: POST

To create a task using the Universal template, you need to send parameters. The Universal template is automatically created in the system, while additional templates should be pre-configured in the PTM interface.

### Parameters for a Universal template task

For a task with the Universal template, the following parameters are used:

1\. external_id: External task identifier (string, default is NULL)

2\. vehicle_plate: Vehicle license plate number (default is NULL). If the number does not exist in the system, it will be created as a rental vehicle

3\. driver_name: Driver's full name (default is NULL). If not specified, the name from the vehicle_plate will be used. If the driver doesn't exist, they will be created as a rental driver

4\. type_name: Task type (default is "Delivery"). If the type doesn't exist, it will be created

5\. template_name: Task template name (default is "Universal"). If the template doesn't exist, it will be created

6\. time_zone: Time zone offset from UTC (number, in minutes from UTC, default is NULL)

7\. time_zone_name: Time zone name (string, default is NULL)

8\. c_begin_time: Scheduled task start time (number — timestamp in seconds, default is current time)

9\. c_return_time: Scheduled task end time (number, default is NULL)

10\. route_name: Route name (string, default is NULL)

11\. cargo: Cargo description (string, default is NULL)

12\. temp_min: Minimum temperature (number, default is 2°C)

13\. temp_max: Maximum temperature (number, default is 8°C)

14\. description: Task description (string, default is NULL)

15\. addresses_list (required): List of addresses or route points (strings with addresses or coordinates)

### Route address parameters

Each route address may include additional parameters with suffixes that describe the route characteristics and geographical data:

1\. addresses_list: List of addresses or route points (strings with addresses or coordinates)

2\. addresses_list_lat: Array of latitudes for the route points

3\. addresses_list_lng: Array of longitudes for the route points

4\. addresses_list_date_point: Array of timestamps (in seconds) for the planned arrival times

5\. addresses_list_date_point_to: Array of timestamps (in seconds) for the planned departure times (automatically calculated if not specified)

6\. addresses_list_time_point: Array of loading/unloading times at the route points (in minutes)

7\. addresses_list_redirect: Flag for redirecting the current address to the next

8\. addresses_list_geofence_id: Geofence IDs for each route point

9\. addresses_list_warehouse: Warehouse or object names for each route point

10\. addresses_list_ticket: Array of unique order identifiers for each route point

11\. addresses_list_phones: Contact phone numbers for each route point

12\. addresses_list_schedule: Working schedule for each route point

13\. addresses_list_vehicle_volume: Cargo volume in the vehicle

14\. addresses_list_trailer_volume: Cargo volume in the trailer

15\. addresses_list_action: Description of actions to perform at each route point

16\. addresses_list_agent_id: Agent ID from the PILOT system, used for trash containers

### Example request

| fetch("https://tasks.pilot-gps.com/backend/public/api/task/create_universal", { "headers": { "Authorization": "Basic ZGVtbzpkZW1v", // base64 encoding "demo:demo" "Content-Type": "application/json" }, "method": "POST", "body": JSON.stringify({ "external_id": "T-5677786754", "vehicle_plate": "PT 125 AA 66", "driver_name": null, "type_name": "Delivery", "template_name": "Universal", "time_zone": -180, "time_zone_name": "Europe/Moscow", "c_begin_time": 1723233360, "c_return_time": 1723238700, "route_name": "My route", "cargo": "Milk", "temp_min": 2, "temp_max": 6, "description": "Test", "addresses_list": [ "215, ul. Narodnogo Opolcheniya, Rostov-on-Don", "47.227196,39.705228", "Client 2" ], "addresses_list_lat": [ 47.234256, 47.227196, 47.216077 ], "addresses_list_lng": [ 39.706467, 39.705228, 39.706928 ], "addresses_list_date_point": [ 1723233360, 1723234800, 1723237800 ], "addresses_list_time_point": [ 10, 20, 15 ], "addresses_list_rad_geo": [ 50, 40, 30 ] }) });  
---|---  
  
### Example response

| { "success": true, "msg": "OK", "httpCode": 200, "data": { "id": 12563 }, "et": 0.5612 }  
---|---

### Waybill — GET 
This API is used to retrieve information about agents’ waybills (tasks) for a specified period.

With it, you can:

— get a list of tasks assigned to each agent

— view planned and actual execution times

— check task statuses and details for route points

## How to get data

### Method

GET

### Request address

To get the data, use the address: https://tasks.<server_address>/backend/public/get_waybill_for_pilot

### Request parameters

  * from_ts— start time of the selection period (Unix timestamp, e.g., 1536181200)

  * to_ts— end time of the selection period (Unix timestamp, e.g., 1538773200)

  * agents— list of agent IDs separated by commas (e.g., 13128,13130,21055)




### Example request

| https://tasks.<server_address>/backend/public/get_waybill_for_pilot?from_ts=1536181200&to_ts=1538773200&agents=13128,13130,21055  
---|---  
  
Response

| { "success": true, "msg": "", "items": [ { "agent_id": 13128, "c_begin_time": "1536200000", "c_end_time": "1536210000", "c_information": "{\"route\":\"Route №54\",\"driver\":\"Ivanov I.I.\"}", "c_initiator": "Dispatcher", "c_progress_time": "1536200500", "c_running_time": "1536200300", "c_status_id": 2, "c_status_name": "Completed", "id": 98765, "points_info": [ { "point_id": 1, "lat": "55.7558", "lon": "37.6173", "visited_at": "1536200600" } ] } ] }  
---|---  
  
In response to the API request, the following is returned:

  * success — execution result (true = success, false = error)

  * msg — error message (if any)

  * items — array of task data




For each task:

  * agent_id — agent identifier

  * c_begin_time — planned task start time

  * c_end_time — actual task end time

  * c_information — string with additional task info (JSON, depends on the template)

  * c_initiator — initiator (who created the task)

  * c_progress_time — actual time of the first point visit

  * c_running_time — actual time of departure to start the task

  * c_status_id — task status ID

  * c_status_name — task status description

  * id — task identifier in the PTM system

  * points_info — array with details of visited route points:

  * point_id — route point ID

  * lat — latitude of the point

  * lon — longitude of the point

  * visited_at — timestamp when the point was visited


---
name: pilot-api
description: Operate Pilot GPS programmatically — list/track vehicles, manage accounts, send commands, configure webhooks, query analytics. Use when the user asks anything about Pilot Telematics, pilot-gps.com, adm.pilot-gps.com, the Kvadrat fleet, IMEIs, plates, agentid, AGS, BLADE/KSA/AFRICA nodes, or wants to do something "in pilot" — checking a vehicle, exporting a track, creating an account, sending a relay command, etc.
---

# Pilot GPS — programmatic control manual

This skill makes you fully capable in the Pilot Telematics environment via API, without touching the web UI. Sourced 2026-05-02 from doc.pilot-gps.com (EN) and doc.pilot-gps.ru (RU) plus the official OpenAPI specs.

## When to use

Trigger this skill any time the user wants to:
- Look up a vehicle (by IMEI, plate, agentid, VIN, SIM, ICCID)
- Get current location, track history, mileage, fuel, sensors
- Send a command to a vehicle (relay/output template)
- Create / edit / block an account, vehicle, folder
- Add fuel transactions, manage drivers/iButtons, geofences
- Subscribe to webhook notifications
- Run BI/analytics queries (Power BI export)
- Build an AI agent over the Rental Booster module
- Fix something that calls `pilot_live_service.py` or anything pointing at `pilot-gps.com`

## TL;DR — three API surfaces

| API | Auth | Use it for |
|---|---|---|
| **v3 REST** (`/api/v3/...`) | JWT bearer token + `X-Node-Id` header | Modern fleet ops, vehicles, tracks, sensors, fuel, drivers, geofences, notifications, commands. **Default for new code.** |
| **Legacy v.2** (`/api/api.php?cmd=...`) | HTTP Basic (user creds) | Endpoints not yet in v3 (waybills, raw imei lookups, some folder ops, atom linux commands). |
| **Admin** (`/ax/api.php?cmd=...`, also `/backend/`) | HTTP Basic (admin creds) | Account creation, billing, vehicle add/move, partner mgmt, raw points. |

Plus three smaller side APIs:
- **BI Analytics** (`POST /api/bi/login.php` then `/api/bi/analytics.php`) — bearer token, throttled. For Power BI / Qlik metric exports.
- **AI Agent / Rental Booster** (`/backend/rental_booster/ai_agent/...`) — JWT, contract-scoped. For LLM agents over rental fleet.
- **Localrent RB** (`/users/authenticate` + reservation endpoints) — for localrent.com integration.

## Servers (regions / nodes)

The Pilot platform is a multi-region cluster. Pick the right host:

| Server | URL | Notes |
|---|---|---|
| Production global | `https://pilot-gps.com` | Default for most accounts |
| **Sandbox / dev** | `https://boooch.pilot-gps.com` | Test API changes here first |
| Africa | `https://pilot-gps.africa` | African contracts |
| BLADE | `https://blade.pilot-gps.com` | Some EU/RU contracts |
| **KSA** | `https://ksa.pilot-gps.com` | Saudi Arabia |
| Admin global | `https://admin.pilot-gps.com` | Admin API root for `/ax/api.php` |
| Admin live (Kvadrat used) | `https://adm.pilot-gps.com` | The host our `pilot_live_service.py` talks to |

Inside a host, requests are routed to a **node** (numeric, e.g. `node=14`). The auth response gives you `node_id`; pass it as `X-Node-Id` header (v3) or `node=` query param (legacy). If you don't, the request hops to the right node but adds latency.

## Existing Kvadrat code paths

Already wired up in this repo — don't re-implement, extend:

- [`telegabot/kvadrat-scheduler/services/pilot_live_service.py`](../../../Documents/KVADRAT%20AGENT%20HUB/telegabot/kvadrat-scheduler/services/pilot_live_service.py) — async client for `adm.pilot-gps.com` admin panel API. JWT login (`/backend//login.php` — `cmd=get_user_without_auth` then `cmd=login`), 4h cached token, `lookup_imei()` and `lookup_by_plate()` against `/backend/app/vehicles.php?cmd=read`. Constructor: `PilotLiveService(username, password, partner_email)`.
- [`telegabot/kvadrat-scheduler/services/pilot_service.py`](../../../Documents/KVADRAT%20AGENT%20HUB/telegabot/kvadrat-scheduler/services/pilot_service.py) — older CSV-based lookup. Still used as fallback.

The live service already covers the **admin panel UI's internal API** (different surface from `/ax/api.php`). For everything else — public v.2/v.3 — write fresh against the patterns below.

## Authentication recipes

### v3 REST (use this for new code)

```python
import requests

BASE = "https://ksa.pilot-gps.com"  # pick your region
auth = requests.post(
    f"{BASE}/api/v3/auth/token",
    json={"username": USER, "password": PASS},
    timeout=15,
).json()
TOKEN = auth["token"]
NODE = auth["node_id"]
S = requests.Session()
S.headers.update({
    "Authorization": f"Bearer {TOKEN}",
    "X-Node-Id": str(NODE),
})

# Now you can hit any v3 endpoint
me = S.get(f"{BASE}/api/v3/auth/me").json()
vehicles = S.get(f"{BASE}/api/v3/vehicles").json()
```

Tokens have a `expires_in` lifetime (returned by `/auth/token`). Re-login when it expires. v3 also supports cookie-session auth when called from inside a "PILOT Extension" (no token needed).

### Legacy v.2 (Basic auth, user creds)

```python
import requests
from requests.auth import HTTPBasicAuth

BASE = "https://pilot-gps.com"
auth = HTTPBasicAuth(USER, PASS)

vehicles = requests.get(
    f"{BASE}/api/api.php",
    params={"cmd": "list", "node": 1},
    auth=auth, timeout=15,
).json()
# {"code": 0, "msg": "OK", "list": [...]}
assert vehicles["code"] == 0
```

Add `out=xml` to get XML instead of JSON.

### Admin v.2 (Basic auth, admin creds)

Same pattern, different base path:
```python
acc = requests.get(
    f"{BASE}/ax/api.php",
    params={"cmd": "accountslist", "node": 1},
    auth=HTTPBasicAuth(ADMIN_USER, ADMIN_PASS), timeout=15,
).json()
```

### Admin panel internal API (what `pilot_live_service.py` uses)

Different again — JWT, two-step login, hits `adm.pilot-gps.com/backend/...`. Already implemented; reuse [`PilotLiveService`](../../../Documents/KVADRAT%20AGENT%20HUB/telegabot/kvadrat-scheduler/services/pilot_live_service.py).

### BI Analytics

```python
tok = requests.post(f"{BASE}/api/bi/login.php",
    json={"username": USER, "password": PASS}).json()
# {"token": "...", "user": {"node_id": 10, ...}}
metrics = requests.post(
    f"{BASE}/api/bi/analytics.php",
    params={"node_id": tok["user"]["node_id"]},
    headers={"Authorization": f"Bearer {tok['token']}"},
    json={
        "date_from": "2026-04-01",
        "date_to":   "2026-04-30",
        "metrics":   ["mileage", "fuel_consumed"],
        "source":    "vehicles",
        "group_by":  "day",
    },
).json()
```

Default rate limits: 100/hr, 2000/day, 50000/month. Activate by setting `bi_analytics: 1` in the partner's `json_config`.

## Key v3 endpoints (the 36 most useful)

Auth + Discovery:
- `POST /api/v3/auth/token` — get bearer token + node_id
- `GET  /api/v3/auth/me` — current user
- `GET  /api/v3/vehicles` — list of fleet vehicles
- `GET  /api/v3/vehicles/by-plate?vehnum=...` — IMEI lookup by plate
- `GET  /api/v3/vehicles/status?imei=...` — current location, speed, sensor states (multi: `imei` is comma-list)
- `GET  /api/v3/vehicles/last24h?imei=...` — 24h history
- `GET  /api/v3/vehicles/instant-status?imei=...&start=...` — odometer + fuel at a timestamp

Tracks & history (period queries take `start`/`stop` Unix timestamps):
- `GET /api/v3/vehicles/track?imei=...&start=...&stop=...&fences=1&eco=1` — point sequence
- `GET /api/v3/vehicles/track/geo` — trips & parking structure
- `GET /api/v3/vehicles/track/stops` — parking-only
- `GET /api/v3/vehicles/trips` — aggregated mileage/avg speed
- `GET /api/v3/vehicles/events/raw` — raw points
- `GET /api/v3/vehicles/forecast_here?origin=lat,lon&destination=lat,lon&mode=car` — HERE routing (needs HERE key in contract)

Sensors:
- `GET /api/v3/vehicles/sensors/dip?imei=...&start=&stop=&tag_id=...` — dip sensor history
- `GET /api/v3/vehicles/sensors/discrete` — discrete state changes
- `GET /api/v3/vehicles/sensors/eco` — eco-driving metrics

Fuel:
- `GET /api/v3/fuel/stations` — fuel station catalog
- `POST /api/v3/fuel/transactions` — record a refuel
- `GET /api/v3/vehicles/fuel?imei=...&start=&stop=` — refuels & drains
- `GET /api/v3/vehicles/fuel/consumption` — consumed + idle time
- `GET /api/v3/vehicles/odo-fuel` — odometer + fuel for period

Drivers / iButton:
- `GET  /api/v3/drivers` / `POST /api/v3/drivers` — list / create-update
- `GET  /api/v3/drivers/activity?driver_id=...` — driver activity report
- `GET  /api/v3/ibuttons` — global iButton history
- `GET  /api/v3/vehicles/ibuttons?imei=...` — per-vehicle iButton history
- `POST /api/v3/vehicles/driver-bind` — assign driver to vehicle

Geofences:
- `GET    /api/v3/geofences`
- `POST   /api/v3/geofences` — create
- `DELETE /api/v3/geofences?id=...` — delete
- `GET    /api/v3/geofences/visits?imei=...&start=&stop=`
- `GET    /api/v3/geofences/mileage?imei=...&fences=name1,name2`

Notifications:
- `GET /api/v3/notifications?start=&stop=&notification=...` — module events
- `GET /api/v3/events/live` — live event stream
- `GET /api/v3/stations/{stopId}/forecast` — bus stop arrival forecast

Commands & sharing:
- `POST /api/v3/vehicles/commands?imei=...` (body: `template_name`) — send command (legacy `cmd=send_command`)
- `GET  /api/v3/vehicles/commands/status?imei=...&command_id=...`
- `GET  /api/v3/vehicles/share-link?imei=...&max_duration=60&startgeo=...&stopgeo=...` — temporary tracking URL

Passenger flow (bus mode): `GET /api/v3/vehicles/passengers?imei=...&start=&stop=`

**Full v3 reference with all parameters and request bodies:** see [`reference/v3_endpoints.md`](reference/v3_endpoints.md).

## Legacy v.2 + Admin command catalog (95 commands)

Don't reach for these unless v3 doesn't have it. The full reference with parameter lists, example requests, and response schemas for every command is at [`reference/legacy_v2_admin.md`](reference/legacy_v2_admin.md). High-value entries:

**User v.2** (`/api/api.php?cmd=...`):
| cmd | What |
|---|---|
| `list` | Vehicle list with sensors |
| `status` | Current vehicle status |
| `vehinfo_24_hours` | Daily summary |
| `gettrack` | Track points |
| `run` / `runstops` / `rungeo` | Trip / parking / geo reports |
| `istatus` | Mileage + fuel level |
| `distance` | Trip stats |
| `fuelconsumtion` | Fuel + idle (sic — typo in real cmd) |
| `get_idle` | Idle time |
| `get_temp_link` | Tracking share link |
| `send_command` / `get_command_status` | Send & poll commands |
| `add_fuel_transaction` / `fuel` / `azs` | Fuel cards & stations |
| `get_report` / `reports_list` | Stored reports |
| `add_geofence` / `geofence_list` / `delete_geofence` | Geofences |
| `link_geofence_to_object` / `unlink_geofence_from_object` | Geofence assignment |
| `geofence_visit_history` / `mileage_inside_geofences` | Geofence analytics |
| `create_driver` / `drivers_list` / `assign_driver_to_vehicle` | Drivers |
| `create_user` / `update_user_login_and_password` / `delete_user` | User mgmt |
| `create_waybill` / `waybill_information` / `delete_waybill` | Waybills (PTM) |
| `imei_by_vehicle_number` | IMEI lookup by plate |
| `raw_data_by_imei` | Raw device frames |
| `eco_driving_data` | Eco-driving |
| `timezone_list` | Timezones |

**Admin** (`/ax/api.php?cmd=...`):
| cmd | What |
|---|---|
| `accountadd` | Create account (returns generated login + password) |
| `accountslist` / `users` | Account & user lists |
| `pricelist` / `payment` | Tariff & billing |
| `vehadd` / `vehedit` / `vehinfo` / `veh_move_account` | Vehicle CRUD |
| `vehicles` | Account objects status |
| `vehtypelist` / `vehmodellist` | Vehicle type & equipment catalogs |
| `setvehblock` | Block / unblock vehicle |
| `rawpoints` | Raw GPS frames |
| `addfolder` / `editfoldername` / `getfolders` / `deletefolder` | Folder CRUD |
| `modlist` | Module list |
| `atom_create_command` / `atom_delete_command` / `atom_get_all` / `atom_get_commands` | Atom Linux command templates |

## Webhooks (push notifications)

Pilot can POST event JSON to your URL when a notification fires. Configure inside the notification's "Type and name" → Webhook. Body uses `%PLACEHOLDERS%`:

| Placeholder | Sends |
|---|---|
| `%ACCOUNTID%` | Account ID |
| `%AGENTID%` | Object ID (vehicle) |
| `%VEHNUM%` | Plate |
| `%TS%` / `%DATETIME%` | Unix ts / formatted |
| `%LAT%` / `%LON%` / `%SPEED%` / `%ODO%` | GPS + sensor |
| `%DATA%` / `%ZONE%` / `%ZONE_ID%` / `%ZONE_NAME%` | Notification data + geofence |
| `%DRIVER%` | Driver |
| `%MAXSPEED%` / `%DUR%` / `%SPEEDLIMIT%` | Overspeed details |
| `%<Sensor Name>%` | Any sensor by name |
| `%<Raw Param>%` | Any raw device param |

Default body template:
```json
{"agent_id":"%AGENTID%","vehiclenumber":"%VEHNUM%","ts":"%TS%","lat":"%LAT%","lon":"%LON%","speed":"%SPEED%","data":"%DATA%","zone":"%ZONE%","driver":"%DRIVER%"}
```

Receivers must respond `200`. Repeated failures temporarily blacklist the URL.

## Common workflows

### Find a vehicle by plate, then get its track for yesterday

```python
import time, requests
BASE = "https://pilot-gps.com"
S = requests.Session()
S.headers.update({"Authorization": f"Bearer {TOKEN}", "X-Node-Id": str(NODE)})

veh = S.get(f"{BASE}/api/v3/vehicles/by-plate", params={"vehnum": "T62968"}).json()
imei = veh["imei"]   # or veh["data"]["imei"] depending on response shape

now = int(time.time())
track = S.get(f"{BASE}/api/v3/vehicles/track", params={
    "imei": imei,
    "start": now - 86400,
    "stop":  now,
    "fences": 1,
    "eco": 1,
}).json()
```

### Send a relay command via legacy API

```python
out = requests.get(f"{BASE}/api/api.php", params={
    "cmd": "send_command",
    "agent_id": 139849,
    "template_name": "engine_block",
    "node": 1,
}, auth=HTTPBasicAuth(USER, PASS)).json()
# {"code":0, "command_id": 3989}
```

Then poll status:
```python
status = requests.get(f"{BASE}/api/api.php", params={
    "cmd": "get_command_status",
    "command_id": out["command_id"],
    "node": 1,
}, auth=HTTPBasicAuth(USER, PASS)).json()
```

### Create a new account (admin)

```python
new = requests.post(f"{BASE}/ax/api.php", params={
    "cmd": "accountadd",
    "bill_price": 143,                    # from pricelist
    "inn": "123456789012",
    "org_name": "Acme LLC",
    "bill_email": "ops@acme.example",
    "acc_type": 1,                        # 1=postpaid 2=prepaid 3=postpaid-light
    "org_type": 1,                        # 1=legal 2=individual 3=sole-prop
    "node": 1,
}, auth=HTTPBasicAuth(ADMIN_USER, ADMIN_PASS)).json()
# {"code":0, "data":{"id":"4018","login":"ops@acme.example","password":"blPs0S"}, "msg":"OK"}
```

### Subscribe to live events (long-poll)

```python
events = S.get(f"{BASE}/api/v3/events/live").json()
# Stream of current events. Treat as a snapshot — re-poll for fresh data.
```

## Response conventions

All legacy endpoints return:
```json
{"code": 0, "msg": "OK", ...payload}
```
- `code == 0` → success; `code == 1` → error (read `msg`)
- v3 returns native HTTP statuses (`200` ok, `401` invalid token, etc.) and ErrorResponse JSON on failures.

## Data types worth remembering

- **`agentid`** (int) — Pilot's internal vehicle ID (a.k.a. "object ID"). Stable.
- **`imei`** (15-digit string) — device IMEI. Best lookup key.
- **`vehiclenumber`** (string) — license plate (sometimes contains model: `"T62968 X70"`).
- **`uniqid`** in admin internal API == IMEI.
- **`ts` / `unixtimestamp`** — always Unix seconds (UTC).
- Coordinates are decimal degrees as strings or floats — both occur, normalize.

## Troubleshooting

- **401 on v3** → token expired (default ~24h). Re-call `/api/v3/auth/token`.
- **`code: 1, msg: "..."`** on legacy → read msg, often "wrong cmd" / missing param / wrong node.
- **Empty result on plate lookup** → plate may be stored with a model suffix; try IMEI instead, or use `vehinfo` admin cmd.
- **CORS error from browser to admin host** → not allowed; use server-side.
- **Hits the wrong node** → pass `node=N` (legacy) or `X-Node-Id: N` (v3). Get correct node from auth response.
- **SSL cert verify failed against `adm.pilot-gps.com`** → known issue, our `pilot_live_service.py` uses `ssl.CERT_NONE` for that host.

## Reference files in this skill

- [`reference/v3_endpoints.md`](reference/v3_endpoints.md) — every v3 endpoint with full parameter list (resolved $refs)
- [`reference/legacy_v2_admin.md`](reference/legacy_v2_admin.md) — every legacy + admin command with parameters, request example, response schema (the full scraped pages)
- Raw OpenAPI specs: `Documents/KVADRAT AGENT HUB/pilot-docs-scrape/openapi/{v3.en,v3.ru,bi.en,bi.ru,localrent-rb-api,ai-agent-rb-api}.yaml`
- Raw HTML cache: `Documents/KVADRAT AGENT HUB/pilot-docs-scrape/raw_com/` (1212 pages)

When unsure of a parameter, grep `reference/legacy_v2_admin.md` for the cmd or grep `reference/v3_endpoints.md` for the path.

## Source URLs (for refresh)

- Live Swagger UI: https://pilot-swagger.pilot-gps.com/
- HTML docs (EN): https://doc.pilot-gps.com/contents.html
- HTML docs (RU): https://doc.pilot-gps.ru/contents.html
- OpenAPI specs are loaded from `https://pilot-gps.com/doc/api/{v3.en,v3.ru,bi.en,bi.ru,localrent-rb-api,ai-agent-rb-api}.yaml`

To refresh: re-run `Documents/KVADRAT AGENT HUB/pilot-docs-scrape/crawl.py` then re-run the build scripts that generated the reference files (see git/timestamps in `pilot-docs-scrape/`).
